#include "TTank.h"

#include <io.h>
#include <process.h>

#include <string>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

/** Required for MYSQL calls */
#ifdef WIN32
#include <windows.h>
#endif

#include "mysql.h"

/**
 * DEFINES
 */

/** Prints MYSQL connection alerts */
#define DEBUG1 true

/** Prints gathered queue data */
#define DEBUG2 true

/** Prints all tanks in the TankServer */
#define DEBUG3 true

/** Size of copyFile buffer per read/write */
#define BUFFER_SIZE 4096

/** Amount of time to sleep between queue checks */
#define SLEEP_TIME_SEC 3

/** Number of queue checks to do before giving up */
#define MAX_CHECKS 4

/** Location of TDT Tanks in registry */
#define REG_KEY "HKEY_LOCAL_MACHINE\\Software\\TDT\\TTank\\EnumTanks"

/**
 * FUNCTION HEADERS 
 */

/** Copies the set of tank files from remote to local root */
void copyTankFiles (string,string,string);

/** Finalizes all open connections */
void finalize (MYSQL*, TTank*, int);

/** Gather the queue elements */
int gatherQueueElements (MYSQL*,string*,long*,long*,float*,float*,long*);

/** Make the MYSQL Connection */
MYSQL* makeMysqlConnection (char*,char*,char*,char*,int);


/**
 * Main entry into function. 
 */
int main (int argc, char *argv[]) {

  MYSQL *conn = makeMysqlConnection ("uberwalton","joe","joepass","db_util",3306);

  if (DEBUG1) cout << "Connected!" << endl << mysql_stat(conn) << endl;

  if (DEBUG1) cout << "MySQL Thread ID: " << mysql_thread_id(conn) << endl;

  string tank;
  int result = -1, numChecks = 0;
  long max_snips, min_snips, insertID;
  float noise_var, dec_factor;

/**
  // Check once
  result = gatherQueueElements(conn,&tank,&max_snips,&min_snips,
               &noise_var,&dec_factor,&insertID);

  // Now loop until we find an element, or hit max-iterations
  while (result == -1 && numChecks < MAX_CHECKS) {

    cout << "(" << numChecks << ") Sleeping ..." << endl;

    Sleep(SLEEP_TIME_SEC*1000);

    result = gatherQueueElements(conn,&tank,&max_snips,&min_snips,
                 &noise_var,&dec_factor,&insertID);

    numChecks++;
  }

  mysql_close(conn);
  if (DEBUG1) cout << "Disconnected!" << endl;

  // If we ended due to numChecks exceeding MAX_CHECKS, quit
  if (result == -1) {
    cerr << "Error: MAX_CHECKS exceeded!" << endl;
    finalize(conn,NULL,1);
  }

  if (DEBUG2)
    cout << "Tank: " << tank << " MaxSnips: " << max_snips 
         << " MinSnips: " << min_snips << " NoiseVar: " 
         << noise_var << " DecFactor: " << dec_factor 
         << " (" << insertID << ")" << endl;
**/
  tank = "070913A";

  string tankRoot = "\\\\172.18.232.53\\Tanks\\";
  string localRoot = "C:\\usr\\cpp\\Single_Unit\\AutoClasser\\";

  string tankPath = tankRoot + tank;

  // Verify we have read access to the remote tanks
  if ((_access((tankPath + ".tbk").c_str(),0) != 0) ||
      (_access((tankPath + ".tdx").c_str(),0) != 0) ||
      (_access((tankPath + ".tev").c_str(),0) != 0) ||
      (_access((tankPath + ".tsq").c_str(),0) != 0)) {
    cerr << "Error: can't find specified tank on shared drive!" << endl;
    finalize(conn,NULL,1);
  }

/**
  // Copy the files from remote to local
  cout << "Copying files ..." << endl;

  try {
    copyTankFiles(tankRoot,localRoot,tank);
  } catch (string* s) {
    cerr << "Exception: " << *s << endl;
    finalize(conn,NULL,1);
  }

**/

  cout << "Done copying files!" << endl;

  // Now verify that the local files were created
  if ( (_access((localRoot + tank + ".tbk").c_str(),04) != 0) ||
       (_access((localRoot + tank + ".tdx").c_str(),04) != 0) ||
       (_access((localRoot + tank + ".tev").c_str(),04) != 0) ||
       (_access((localRoot + tank + ".tsq").c_str(),04) != 0) ) {
    cerr << "Error: can't find specified tank on local drive s/p copying!" << endl;
    finalize(conn,NULL,1);
  }

  TTank* tt;

  try {
    tt = new TTank("Local");
  } catch (string* s) {
    cerr << "Exception: " << *s << endl;
    finalize(conn,NULL,1);
  }

  // Remove the tank if it's contained previously
  if (tt->containsTank(tank))
    tt->removeTank(tank);
  
  // Now add it
  if (tt->addTank(tank,localRoot) != 0) {
    cerr << "Error adding tank " << tank << endl;
    finalize(conn,tt,-1);
  }

  vector<string> servers = tt->getServers();
  cout << "Number of servers: " << servers.size() << endl;

  vector<string> tanks = tt->getTanks();
  cout << "Number of tanks: " << tanks.size() << endl;

  if (DEBUG3) {
    vector<string>::iterator it;
    for (it = tanks.begin(); it != tanks.end(); ++it)
      cout << "\t" << *it << endl;
  }

  // When we're done, remove the tank
  tt->removeTank(tank);

  tanks = tt->getTanks();
  cout << "Number of tanks: " << tanks.size() << endl;

  if (DEBUG3) {
    vector<string>::iterator it;
    for (it = tanks.begin(); it != tanks.end(); ++it)
      cout << "\t" << *it << endl;
  }

  // Removes the local files
/**
  if ( (remove((localRoot + tank + ".tbk").c_str()) != 0) ||
       (remove((localRoot + tank + ".tdx").c_str()) != 0) || 
       (remove((localRoot + tank + ".tev").c_str()) != 0) ||
       (remove((localRoot + tank + ".tsq").c_str()) != 0) ) {
    cerr << "Error deleting local files!" << endl;
    finalize(conn,tt,1);
  }
**/

  finalize(conn,tt,0);
}

/**
 * Copies all four of the tank files from the remote directory to the 
 * local directory.
 */
void copyTankFiles (string remoteDir, string localDir, string tank) {

  if ( system(("copy " + remoteDir + tank + ".tbk " 
                       + localDir + tank + ".tbk").c_str()) != 0)
    throw new string("Error copying " + tank + ".tbk file!");

  if ( system(("copy " + remoteDir + tank + ".tdx " 
                       + localDir + tank + ".tdx").c_str()) != 0)
    throw new string("Error copying " + tank + ".tdx file!");

  if ( system(("copy " + remoteDir + tank + ".tev " 
                       + localDir + tank + ".tev").c_str()) != 0)
    throw new string("Error copying " + tank + ".tev file!");

  if ( system(("copy " + remoteDir + tank + ".tsq " 
                       + localDir + tank + ".tsq").c_str()) != 0)
    throw new string("Error copying " + tank + ".tsq file!");

  return;
}

/**
 * Finalizes all open connections prior to calling exit, with the 
 * given error code.
 */
void finalize (MYSQL *conn, TTank *tt, int exitCode) {

  try {
    mysql_close(conn);
  } catch (string* s) {}

  try {
    mysql_server_end();
  } catch (string* s) {}

  try {
    tt->closeServer();
  } catch (string* s) {}

  exit(exitCode);
}


/**
 * Lock the tables, get the queue elements, transfer to progress table,
 * and unlock the tables. Returns -1 on no elements ready, 0 on success.
 */
int gatherQueueElements (MYSQL* conn, string* tank, long* max_snips, long* min_snips, 
        float* noise_var, float* dec_factor, long* insertID) {

  int result;
  string sql;
  stringstream sql_buf;

  // First thing is to lock the tables necessary
  sql_buf.str("");
  sql_buf << "LOCK TABLES classing_queue WRITE, "
          << "classing_queue AS q READ, classing_progress WRITE";

  sql = sql_buf.str();
  result = mysql_real_query(conn,sql.c_str(),sql.length());

  if (result != 0) {
    cerr << "Error locking tables on dB: " << mysql_error(conn) << endl;
    mysql_close(conn);
    exit(1);
  }

  // Now get the data from the classing_queue table
  sql_buf.str("");
  sql_buf << "SELECT q.id, q.tank, q.max_snips, q.min_snips, "
          << "q.noise_var, q.dec_factor " 
          << "FROM classing_queue q "
          << "ORDER BY q.ts LIMIT 1";

  sql = sql_buf.str();
  result = mysql_real_query(conn,sql.c_str(),sql.length());

  if (result != 0) {
    cerr << "Error querying database!" << endl;
    mysql_close(conn);
    exit(1);
  }

  MYSQL_RES *res;
  // Verify that the result is present, and that fields are present
  if ((res = mysql_store_result(conn)) == NULL) {
    if (mysql_field_count(conn) == 0) {
      cerr << "No fields returned from query!" << endl;
      mysql_close(conn);
      exit(1);
    } else {
      cerr << "MYSQL ERROR: " << mysql_error(conn) << endl;
      mysql_close(conn);
      exit(1);
    }
  }

  long nrow, nfield;

  // Get number of rows, fields in result set
  nrow = mysql_num_rows(res);
  nfield = mysql_num_fields(res);

  // If there aren't any rows, unlock the tables and return -1
  if (nrow == 0) {
    mysql_free_result(res);

    sql_buf.str("");
    sql_buf << "UNLOCK TABLES";

    sql = sql_buf.str();
    result = mysql_real_query(conn,sql.c_str(),sql.length());

    if (result != 0) {
      cerr << "Error unlocking tables on dB: " << mysql_error(conn) << endl;
      mysql_close(conn);
      exit(1);
    }

    return -1;
  }

  if (nrow > 1) {
    cerr << "Error: more than one row returned!" << endl;
    mysql_free_result(res);
    mysql_close(conn);
    exit(1);
  }

  if (nfield != 6) {
    cerr << "Error: should have 6 fields!" << endl;
    mysql_free_result(res);
    mysql_close(conn);
    exit(1);
  }

  if (DEBUG1) cout << "NumRows: " << nrow << " NumFields: " << nfield << endl;

  MYSQL_FIELD *f;
  // Get the fields
  f = mysql_fetch_fields(res);

  if (f == NULL) {
    cerr << "Error fetching fields from query!" << endl;
    mysql_free_result(res);
    mysql_close(conn);
    exit(1);
  }

  // Verify returned types
  if (f[0].type != MYSQL_TYPE_LONG)       cout << "f[0] incorrect" << endl;
  if (f[1].type != MYSQL_TYPE_VAR_STRING) cout << "f[1] incorrect" << endl;
  if (f[2].type != MYSQL_TYPE_LONG)       cout << "f[2] incorrect" << endl;
  if (f[3].type != MYSQL_TYPE_LONG)       cout << "f[3] incorrect" << endl;
  if (f[4].type != MYSQL_TYPE_FLOAT)      cout << "f[4] incorrect" << endl;
  if (f[5].type != MYSQL_TYPE_FLOAT)      cout << "f[5] incorrect" << endl;

  // Seek to the first row - to reset seek head to start
  mysql_data_seek(res,0);

  MYSQL_ROW row;
  row = mysql_fetch_row(res);
  if (row == NULL) {
    cerr << "Error fetching row data!" << endl;
    mysql_free_result(res);
    mysql_close(conn);
    exit(1);
  }

  int f_ = 0;
  long id;

  sscanf_s(row[f_++],"%ld",&id);
  
  // Get the tank name
  char* tank_str = new char[strlen(row[f_])];
  strcpy_s(tank_str,strlen(row[f_])+1,row[f_]);
  tank = new string(tank_str);
  f_++;

  sscanf_s(row[f_++],"%ld",max_snips);
  sscanf_s(row[f_++],"%ld",min_snips);
  sscanf_s(row[f_++],"%f",noise_var);
  sscanf_s(row[f_++],"%f",dec_factor);

  // Now we need to insert into the other table
  sql_buf.str("");
  sql_buf << "INSERT INTO classing_progress (computer,tank,startTime) VALUES " 
          << "(SUBSTRING_INDEX(USER(),\"@\",-1),'" << *tank << "',CURRENT_TIMESTAMP)";

  sql = sql_buf.str();
  result = mysql_real_query(conn,sql.c_str(),sql.length());

  if (result != 0) {
    cerr << "Error inserting into classing progress table: " 
         << mysql_error(conn) << endl;
    mysql_close(conn);
    exit(1);
  }

  // Get and save the insertID
  *insertID = mysql_insert_id(conn);

  // And delete the ID'd element from the classing_queue
  sql_buf.str("");
  sql_buf << "DELETE FROM classing_queue WHERE id = " << id;

  sql = sql_buf.str();
  result = mysql_real_query(conn,sql.c_str(),sql.length());

  if (result != 0) {
    cerr << "Error deleting old element from classing_queue: " 
         << mysql_error(conn) << endl;
    mysql_close(conn);
    exit(1);
  }

  // And lastly we unlock the tables
  sql_buf.str("");
  sql_buf << "UNLOCK TABLES";

  sql = sql_buf.str();
  result = mysql_real_query(conn,sql.c_str(),sql.length());

  if (result != 0) {
    cerr << "Error unlocking tables on dB: " << mysql_error(conn) << endl;
    mysql_close(conn);
    exit(1);
  }

  // Free the result set
  mysql_free_result(res);

  return 0;
}

/**
 * Creates a new MYSQL connection.
 */
MYSQL* makeMysqlConnection (char* host, char* user, 
    char* pwd, char* db, int port) {

  MYSQL *conn = NULL;
  if ((conn = mysql_init(conn)) == NULL) {
    cerr << "Couldn't initialize MYSQL connection!" << endl;
    exit(1);
  }

  if (!mysql_real_connect(conn, host, user, pwd, db, port, NULL, 0)) {
    cerr << "Couldn't connect to MYSQL server!" << endl;
    exit(1);
  }

  return conn;
}