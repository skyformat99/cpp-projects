// Audio.cpp: implementation of the CAudio class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Audio.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CAudio::CAudio()
{
   for (unsigned short i = 0; i < 8; i++) Avail[i] = 0;
}

CAudio::~CAudio()
{
   while (!AudioStream.IsEmpty()) delete AudioStream.RemoveHead();
}
/////////////////////////////////////////////////////////////////////////////
//

CAudioStream *CAudio::AddAudioStream()
{
   CAudioStream *tmp = new CAudioStream();
   if (tmp) AudioStream.AddTail(tmp);
   return tmp;
}