// Cell.cpp: implementation of the CCell class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Cell.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCell::CCell(int number)
{
   CCell::number = number;
   Position = 0;
   VobID = 0;
   CellID = 0;
   ChainInfo = 0;
   Angle = 0;
   LBAStart = ULONG_MAX;
   LBAStop = 0;
   Length = 0.0;
   Size = 0;
   AverageDatarate = 0;
   MinDatarate = ULONG_MAX;
   MaxDatarate = 0;
   Selected = 1;
}

CCell::~CCell()
{
}

CString CCell::Name()
{
   CString name;
   name.Format("Cell %d", number + 1);
   return name;
}