// Chapter.cpp: implementation of the CChapter class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Chapter.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CChapter::CChapter(int number)
{
   CChapter::number = number;
   Length = 0.0;
   Size = 0;
   LBAStart = 0;
   LBAStop = 0;
   AverageDatarate = 0;
   MinDatarate = ULONG_MAX;
   MaxDatarate = 0;
   selectedCell = -1;
}

CChapter::~CChapter()
{
   while (!Cell.IsEmpty()) delete Cell.RemoveHead();
}
/////////////////////////////////////////////////////////////////////////////
//

CString CChapter::Name()
{
   CString name;
   name.Format("Chapter %d", number + 1);
   return name;
}
/////////////////////////////////////////////////////////////////////////////
//

void CChapter::Calculate()
{
   Length = 0.0;
   Size = 0;
   LBAStart = ULONG_MAX;
   LBAStop = 0;
   AverageDatarate = 0;
   MinDatarate = ULONG_MAX;
   MaxDatarate = 0;
   selectedCell = 0;

   POSITION pos = Cell.GetHeadPosition();
   while (pos) {
      CCell *pCell = Cell.GetNext(pos);

      if (pCell->IsSelected()) {
         Length += pCell->Length;
         Size += pCell->Size;
         selectedCell++;
         if (pCell->LBAStart < LBAStart) LBAStart = pCell->LBAStart;
         if (pCell->LBAStop > LBAStop) LBAStop = pCell->LBAStop;
         if (pCell->MinDatarate < MinDatarate) MinDatarate = pCell->MinDatarate;
         if (pCell->MaxDatarate > MaxDatarate) MaxDatarate = pCell->MaxDatarate;
      }
   }
   if (MinDatarate == ULONG_MAX) MinDatarate = 0;
   if (Length > 0.0)
      AverageDatarate = unsigned long(((double(Size) * 2048.0) / Length));
}
/////////////////////////////////////////////////////////////////////////////
//

void CChapter::Select()
{
   POSITION pos = Cell.GetHeadPosition();
   while (pos) Cell.GetNext(pos)->Select();
}
/////////////////////////////////////////////////////////////////////////////
//

void CChapter::UnSelect()
{
   POSITION pos = Cell.GetHeadPosition();
   while (pos) Cell.GetNext(pos)->UnSelect();
}

UINT CChapter::Selected()
{
   UINT select = 0;
   POSITION pos = Cell.GetHeadPosition();
   while (pos) {
      select |= (Cell.GetNext(pos)->IsSelected()? LVIS_STATECHK: LVIS_STATENOCHK);
   }
   return select;
}
/////////////////////////////////////////////////////////////////////////////
//

CCell *CChapter::AddCell(  unsigned short Position,
                           unsigned short VobID, unsigned short CellID,
                           unsigned long LBAStart, unsigned long LBAStop,
                           double Length,
                           unsigned long AverageDatarate,
                           unsigned long MinDatarate, unsigned long MaxDatarate)
{
   CCell *tmp = new CCell(Cell.GetCount());
   if (tmp) {
      tmp->Position  = Position;
      tmp->VobID     = VobID;
      tmp->CellID    = CellID;
      tmp->LBAStart  = LBAStart;
      tmp->LBAStop   = LBAStop;
      tmp->Length    = Length;
      tmp->Size = (LBAStop > LBAStart)? LBAStop - LBAStart + 1 : 0;
      tmp->AverageDatarate = AverageDatarate;
      tmp->MinDatarate = MinDatarate;
      tmp->MaxDatarate = MaxDatarate;
      Cell.AddTail(tmp);
   }
   return tmp;
}




//---------------------------------------------------------------------------

