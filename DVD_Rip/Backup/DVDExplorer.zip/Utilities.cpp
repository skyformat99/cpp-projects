// Utilities.cpp: implementation of the Utilities class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Utilities.h"
#include <math.h>       // modf

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Give the length a file

_int64 GetFileLength(LPCTSTR path)
{
   WIN32_FIND_DATA fd;
   HANDLE hd = ::FindFirstFile(path, &fd);
   if (hd == INVALID_HANDLE_VALUE) {
      return -1;
   }
   ::FindClose(hd);
   return fd.nFileSizeLow | (_int64(fd.nFileSizeHigh) << 32);
}

_int64 Round(_int64 length, DWORD rl)
{
   return ((length + rl - 1) / rl) * rl;
}
/////////////////////////////////////////////////////////////////////////////
//

CString msDecode(double time, bool ms)
{
   return msDecode(unsigned long(time), ms);
}

CString msDecode(unsigned long time, bool ms)
{
   unsigned long h, m, s;
   CString out;
   h = time / 3600000; time %= 3600000;
   m = time / 60000; time %= 60000;
   s = time / 1000; time %= 1000;
   if (ms) out.Format("%02d:%02d:%02d:%03d", h, m, s, time);
   else out.Format("%02d:%02d:%02d", h, m, s);
   return out;
}
/////////////////////////////////////////////////////////////////////////////
//

CString toString(unsigned long val, unsigned long max, bool fract)
{
   CString str;

   if (val == ULONG_MAX) val = 0;
   if (max > val || fract) str.Format("%u/%u", val, max);
   else           str.Format("%u", val);

   return str;
}
/////////////////////////////////////////////////////////////////////////////
//

CString Value2Byte(unsigned int Value,unsigned int overdrive)
   // Byte -> String
{
   CString out;
   if (Value < 1024 * overdrive) { // Byte

      out.Format("%d B", Value);
   } else if (Value < 1048576 * overdrive) { // KB
  
      out.Format("%d KB", Value / 1024);
   } else {   // MB

      out.Format("%d MB", Value / 1048576);
   }
   return out;
}
/////////////////////////////////////////////////////////////////////////////
//

CString Value2KB(unsigned int Value)    // KB=>1.000.123 KB
{
    CString msg;
    unsigned int    k, m, g, r;

    k = Value % 1000; r = Value / 1000;
    m = r % 1000; r = r / 1000;
    g = r % 1000;

    if (g > 0) {
        msg.Format("%lu.%03lu.%03lu KB", g, m, k);
    } else if (m > 0) {
        msg.Format("%lu.%03lu KB", m, k);
    } else {
        msg.Format("%lu KB", k);
    }
    return msg;
}
/////////////////////////////////////////////////////////////////////////////
//

CString LBA2Byte(unsigned int Value,unsigned int overdrive)   // LBA -> String
{
   double tmp = double(Value) * 2048;
   double ovd = double(overdrive);
   CString out;

   if (tmp < 1024.0 * ovd) { // Byte

      out.Format("%d B", long(tmp));
   
   } else if (tmp < 1048576.0 * ovd) { // KB

      out.Format("%.0f KB", tmp / 1024.0);

   } else {   // MB

      out.Format("%.0f MB", tmp / 1048576.0);
   }
   return out;
}
/////////////////////////////////////////////////////////////////////////////
//

CString Value2Rate(unsigned int Value, unsigned int overdrive)
   // Bytes/sec -> String
{
   CString out;
   if (Value < 1024 * overdrive) { // Byte

      out.Format("%d B/s", Value);
   } else if (Value < 1048576 * overdrive) { // KB

      out.Format("%d KB/s", Value / 1024);
   } else {   // MB

      out.Format("%d MB/s", Value / 1048576);
   }
   return out;
}
/////////////////////////////////////////////////////////////////////////////
//

/*CString msec2Time(unsigned int msec)
{
    unsigned int    h,
                    m,
                    s,
                    ms,
                    tmp;
    char            msg[100];

    h   = msec/3600000;
    tmp = msec%3600000;
    m   = tmp/60000;
    tmp = tmp%60000;
    s   = tmp/1000;
    ms  = tmp%1000;
    sprintf(msg,"%02d:%02d:%02d.%03d",h,m,s,ms);
    return (CString(msg));
} */
/////////////////////////////////////////////////////////////////////////////
//

CString sec2Time(double sec)
{
   CString out;
   double ip, tmp;

   tmp = modf(sec / 60, &ip);

   unsigned int hm = unsigned int(ip);

   out.Format("%02d:%02d:%02.2f", hm / 60, hm % 60, tmp * 60);

   return out;
}

CString getZones(BYTE z)
{
   CString msg;
   char zone = '1';

   z = ~z;
   while (z) {
      if (z & 1) {
         if (!msg.IsEmpty()) msg += '-';
         msg += zone;
      }
      zone++;
      z >>= 1;
   }
   return msg;
}