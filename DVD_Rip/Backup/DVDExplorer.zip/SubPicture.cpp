// SubPicture.cpp: implementation of the CSubPicture class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SubPicture.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CSubPicture::CSubPicture()
{
   for(int i = 0;i < 32; i++) Avail[i] = -1;
}

CSubPicture::~CSubPicture()
{
   while (!SubPictureStream.IsEmpty()) delete SubPictureStream.RemoveHead();
}
/////////////////////////////////////////////////////////////////////////////
//

CSubPictureStream *CSubPicture::AddSubPictureStream(unsigned char ID,
                                                    unsigned char SubID)
{
   CSubPictureStream *tmp = new CSubPictureStream();
   if (tmp) {
      tmp->ID = ID;
      tmp->SubID = SubID;
      SubPictureStream.AddTail(tmp);
   }
   return tmp;
}
