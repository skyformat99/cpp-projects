// SubPicture.h: interface for the CSubPicture class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SUBPICTURE_H__2ACB37D7_996D_48A8_9C76_8CD155BD8313__INCLUDED_)
#define AFX_SUBPICTURE_H__2ACB37D7_996D_48A8_9C76_8CD155BD8313__INCLUDED_

#include "SubPictureStream.h"
#include <afxtempl.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSubPicture  
{
public:
	CSubPicture();
	virtual ~CSubPicture();

   char Avail[32];

   CList<CSubPictureStream*, CSubPictureStream*> SubPictureStream;

   CSubPictureStream *AddSubPictureStream(unsigned char ID,    // 0xBD
                                       unsigned char SubID);   // 0x2x,0x3x
};

#endif // !defined(AFX_SUBPICTURE_H__2ACB37D7_996D_48A8_9C76_8CD155BD8313__INCLUDED_)
