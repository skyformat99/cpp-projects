// UnitManager.h: interface for the CUnitManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UNITMANAGER_H__25B80D53_BC4C_4DE7_BB84_4DF6822A051C__INCLUDED_)
#define AFX_UNITMANAGER_H__25B80D53_BC4C_4DE7_BB84_4DF6822A051C__INCLUDED_

#include <afxtempl.h>
#include "Unit.h"
#include "Cell.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CUnitManager  
{
public:
	CUnitManager();
	virtual ~CUnitManager();

   CList<CUnit*, CUnit*> Unit;
   CUnit *AddUnit();
   inline CUnit *GetUnitAt(int i) { return Unit.GetAt(Unit.FindIndex(i)); }

   CList<CCell*, CCell*> TSCA;
   CCell *AddTSCACell( unsigned short VobID, unsigned short CellID,
                       unsigned long LBAStart, unsigned long LBAStop);

   void Calculate();
};

#endif // !defined(AFX_UNITMANAGER_H__25B80D53_BC4C_4DE7_BB84_4DF6822A051C__INCLUDED_)
