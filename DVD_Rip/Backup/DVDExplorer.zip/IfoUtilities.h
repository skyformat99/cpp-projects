// IfoUtilities.h: interface for the IfoUtilities class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IFOUTILITIES_H__10A8B132_B687_4C59_A31B_8B43C01397E0__INCLUDED_)
#define AFX_IFOUTILITIES_H__10A8B132_B687_4C59_A31B_8B43C01397E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

extern LPCTSTR recordName[];

extern DWORD   get4Bytes(PBYTE buf);
extern WORD    get2Bytes(PBYTE buf);
extern DWORD   swap32(DWORD dw);
extern WORD    swap16(WORD w);
extern double  BCDtime(PBYTE pTime);

extern LPCTSTR IfoDecodeLang(WORD descr);
extern LPCTSTR AudioModeDecode(WORD descr);
extern LPCTSTR AudioModeApplDecode(BYTE descr);

#endif // !defined(AFX_IFOUTILITIES_H__10A8B132_B687_4C59_A31B_8B43C01397E0__INCLUDED_)
