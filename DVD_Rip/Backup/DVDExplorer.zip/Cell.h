// Cell.h: interface for the CCell class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CELL_H__19B2E296_6172_4791_8CED_5BDBA80B9C6B__INCLUDED_)
#define AFX_CELL_H__19B2E296_6172_4791_8CED_5BDBA80B9C6B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCell  
{
private:
   bool Selected;

public:
	CCell(int number);
	virtual ~CCell();

   int number;                         // 0..n-1
   unsigned short Position;            // first = 0
   unsigned short VobID;
   unsigned short CellID;
   unsigned char ChainInfo;            // for AngleDetection
   unsigned char Angle;
   unsigned long LBAStart;             // in LBA
   unsigned long LBAStop;              // in LBA
   double Length;                      // in sec
   unsigned long Size;                 // in LBA
   unsigned long AverageDatarate;      // in Bytes/sec
   unsigned long MinDatarate;          // in Bytes/sec
   unsigned long MaxDatarate;          // in Bytes/sec
   
   inline void Select() { Selected = true; }
   inline void UnSelect() { Selected = false; };
   inline bool IsSelected() { return Selected; }
   CString Name();
};

#endif // !defined(AFX_CELL_H__19B2E296_6172_4791_8CED_5BDBA80B9C6B__INCLUDED_)
