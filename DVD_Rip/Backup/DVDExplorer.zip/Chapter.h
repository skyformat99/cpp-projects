// Chapter.h: interface for the CChapter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHAPTER_H__B8DE7ABB_993C_4F66_9278_ED75DA3FBF1D__INCLUDED_)
#define AFX_CHAPTER_H__B8DE7ABB_993C_4F66_9278_ED75DA3FBF1D__INCLUDED_

#include "Cell.h"
#include <afxtempl.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef enum {LVIS_STATENOCHK=0x1000, LVIS_STATECHK=0x2000, LVIS_STATECHKMASK=0x3000};

class CChapter  
{
private:
   int selectedCell;

public:
	CChapter(int number);
	virtual ~CChapter();

   int number;                      // 0.. n - 1
   double Length;                   // in msec
   unsigned long Size;              // in LBA
   unsigned long LBAStart;
   unsigned long LBAStop;
   unsigned long AverageDatarate;
   unsigned long MinDatarate;
   unsigned long MaxDatarate;

   CList<CCell*, CCell*> Cell;
   CCell *GetCellAt(int i) { return Cell.GetAt(Cell.FindIndex(i)); }
   CCell *AddCell(unsigned short Position,
                  unsigned short VobID,
                  unsigned short CellID,
                  unsigned long LBAStart,
                  unsigned long LBAStop,
                  double Length = 0.0,
                  unsigned long AverageDatarate = 0,
                  unsigned long MinDatarate = 0xFFFFFFFF,
                  unsigned long MaxDatarate = 0);

   inline int GetSelectedCellCount() { return selectedCell; }
   void Calculate();
   void Select();
   void UnSelect();
   UINT Selected();                 // return a LVIS_STATE
   CString Name();
};

#endif // !defined(AFX_CHAPTER_H__B8DE7ABB_993C_4F66_9278_ED75DA3FBF1D__INCLUDED_)
