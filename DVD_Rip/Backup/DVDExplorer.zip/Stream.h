// Stream.h: interface for the CStream class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STREAM_H__B74E4F33_70B3_4822_877D_9D727B92F547__INCLUDED_)
#define AFX_STREAM_H__B74E4F33_70B3_4822_877D_9D727B92F547__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CStream  
{
public:
	CStream();
	virtual ~CStream();

   unsigned char Type;           // 0-3
   unsigned char ID;             // 0xBD,0xC0,0xC8,...
   unsigned char SubID;          // 0x8x,0xA0,0x00,...
   unsigned char AllowMapping;   // 0=False 1=True
   unsigned char Map;            // 0=False 1=True
   unsigned char mID;            // map to 0xBD,0xC0,0xC8
   unsigned char mSubID;         // map to 0x8x,0xA0
   unsigned char Checked;        // 0=False 1=True
   unsigned char AllowExtraction;// 0=False 1=True
   unsigned char RipMode;        // 0=DirectStream 1=Demux 2=CopyBlock to VOB-file
   unsigned int LBA;
   unsigned int Datarate;
   unsigned int PTS;
   int Delay;
   CString ShortName;            // "[0x80] Audio"
   CString Name;                 // "[0x80] Audio ....."
   CString Ext;                  // "AC3" "DTS"
};

#endif // !defined(AFX_STREAM_H__B74E4F33_70B3_4822_877D_9D727B92F547__INCLUDED_)
