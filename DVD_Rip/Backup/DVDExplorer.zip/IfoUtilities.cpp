// IfoUtilities.cpp: implementation of the IfoUtilities class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "IfoRecords.h"
#include "Movie.h"
#include "IfoUtilities.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

LPCTSTR recordName[] = {
   "MAT", "PTT_SRPT", "PGCI", "MENU_PGCI", "TMAPTI", "MENU_CELL-ADDR",
   "MENU_VOBU_ADDR_MAP", "TITLE_CELL_ADDR", "TITLE_VOBU_ADDR_MAP"
};
/////////////////////////////////////////////////////////////////////////////
// Read word and long in a memory buffer

DWORD get4Bytes(PBYTE pBuf)
{
   return pBuf[3] | (pBuf[2] << 8) | (pBuf[1] << 16) | (pBuf[0] << 24);
}

WORD get2Bytes(PBYTE pBuf)
{
   return pBuf[1] | (pBuf[0] << 8);
}
/////////////////////////////////////////////////////////////////////////////
// Swap long and word

DWORD swap32(DWORD dw)
{
   return (dw << 24) | (((dw >> 8) & 0xFF) << 16)
                           | (((dw >> 16) & 0xFF) << 8) | (dw >> 24);
}

WORD swap16(WORD w)
{
   return (w << 8) | (w >> 8);
}
/////////////////////////////////////////////////////////////////////////////
// Convert a 4 bytes BCD time

double BCDtime(PBYTE pTime)
{
   BYTE time[4];
   double frame_rate;

   time[0] = pTime[0], time[1] = pTime[1], time[2] = pTime[2];
   time[3] = pTime[3] & 0x3F;

   switch( pTime[3] >> 6 ) {
   case 1: frame_rate = 25.0;             break; // PAL
   case 3: frame_rate = 30000.0 / 1001.0; break; // NTSC
   default: frame_rate = 30000.0 / 1001.0;    //Invalid code
   }

   // convert bcd(two digits) to binary
   for (int j = 0; j < 4; j++)
      time[j] = ((time[j] & 0xf0) >> 4) * 10 + (time[j] & 0x0f);

   return double(int(time[0] * 3600 + time[1] * 60 + time[2]))
                                     + double(time[3]) / frame_rate;
}
/////////////////////////////////////////////////////////////////////////////
//
static struct {
        WORD descr;
        LPCTSTR lang_long;
} lang_tbl[] = {

// The ISO 639 language codes.
// Language names with * prefix are not spelled in their own language

	{0,    "Not Specified"},
	{'  ', "Not Specified"},
	{'aa', "Afar"},
	{'ab', "Abkhazian"},
	{'af', "Afrikaans"},
	{'am', "Amharic"},
	{'ar', "Arabic"},
	{'as', "Assamese"},
	{'ay', "Aymara"},
	{'az', "Azerbaijani"},
	{'ba', "Bashkir"},
	{'be', "Byelorussian"},
	{'bg', "Bulgarian"},
	{'bh', "Bihari"},
	{'bi', "Bislama"},
	{'bn', "Bengali; Bangla"},
	{'bo', "Tibetan"},
	{'br', "Breton"},
	{'ca', "Catal�"},
	{'co', "Corsican"},
	{'cs', "Czech(Ceske)"},
	{'cy', "Welsh"},
	{'da', "Dansk"},
	{'de', "Deutsch"},
	{'dz', "Bhutani"},
	{'el', "Greek"},
	{'en', "English"},
	{'eo', "Esperanto"},
	{'es', "Espa�ol"},
	{'et', "Estonian"},
	{'eu', "Basque"},
	{'fa', "Persian"},
	{'fi', "Suomi"},
	{'fj', "Fiji"},
	{'fo', "Faroese"},
	{'fr', "Fran�ais"},
	{'fy', "Frisian"},
	{'ga', "Irish"},
	{'gd', "Scots Gaelic"},
	{'gl', "Galician"},
	{'gn', "Guarani"},
	{'gu', "Gujarati"},
	{'ha', "Hausa"},
	{'he', "Hebrew"},             // formerly iw
	{'hi', "Hindi"},
	{'hr', "Hrvatski"},           // Croatian
	{'hu', "Magyar"},
	{'hy', "Armenian"},
	{'ia', "Interlingua"},
	{'id', "Indonesian"},         // formerly in
	{'ie', "Interlingue"},
	{'ik', "Inupiak"},
	{'in', "Indonesian"},         // replaced by id
	{'is', "Islenska"},
	{'it', "Italiano"},
	{'iu', "Inuktitut"},
	{'iw', "Hebrew"},             // replaced by he
	{'ja', "Japanese"},
	{'ji', "Yiddish"},            // replaced by yi
	{'jw', "Javanese"},
	{'ka', "Georgian"},
	{'kk', "Kazakh"},
	{'kl', "Greenlandic"},
	{'km', "Cambodian"},
	{'kn', "Kannada"},
	{'ko', "Korean"},
	{'ks', "Kashmiri"},
	{'ku', "Kurdish"},
	{'ky', "Kirghiz"},
	{'la', "Latin"},
	{'ln', "Lingala"},
	{'lo', "Laothian"},
	{'lt', "Lithuanian"},
	{'lv', "Latvian, Lettish"},
	{'mg', "Malagasy"},
	{'mi', "Maori"},
	{'mk', "Macedonian"},
	{'ml', "Malayalam"},
	{'mn', "Mongolian"},
	{'mo', "Moldavian"},
	{'mr', "Marathi"},
	{'ms', "Malay"},
	{'mt', "Maltese"},
	{'my', "Burmese"},
	{'na', "Nauru"},
	{'ne', "Nepali"},
	{'nl', "Nederlands"},
	{'no', "Norsk"},
	{'oc', "Occitan"},
	{'om', "(Afan) Oromo"},
	{'or', "Oriya"},
	{'pa', "Punjabi"},
	{'pl', "Polish"},
	{'ps', "Pashto, Pushto"},
	{'pt', "Portugues"},
	{'qu', "Quechua"},
	{'rm', "Rhaeto-Romance"},
	{'rn', "Kirundi"},
	{'ro', "Romanian"},
	{'ru', "Russian"},
	{'rw', "Kinyarwanda"},
	{'sa', "Sanskrit"},
	{'sd', "Sindhi"},
	{'sg', "Sangho"},
	{'sh', "Serbo-Croatian"},
	{'si', "Sinhalese"},
	{'sk', "Slovak"},
	{'sl', "Slovenian"},
	{'sm', "Samoan"},
	{'sn', "Shona"},
	{'so', "Somali"},
	{'sq', "Albanian"},
	{'sr', "Serbian"},
	{'ss', "Siswati"},
	{'st', "Sesotho"},
	{'su', "Sundanese"},
	{'sv', "Svenska"},
	{'sw', "Swahili"},
	{'ta', "Tamil"},
	{'te', "Telugu"},
	{'tg', "Tajik"},
	{'th', "Thai"},
	{'ti', "Tigrinya"},
	{'tk', "Turkmen"},
	{'tl', "Tagalog"},
	{'tn', "Setswana"},
	{'to', "Tonga"},
	{'tr', "Turkish"},
	{'ts', "Tsonga"},
	{'tt', "Tatar"},
	{'tw', "Twi"},
	{'ug', "Uighur"},
	{'uk', "Ukrainian"},
	{'ur', "Urdu"},
	{'uz', "Uzbek"},
	{'vi', "Vietnamese"},
	{'vo', "Volapuk"},
	{'wo', "Wolof"},
	{'xh', "Xhosa"},
	{'yi', "Yiddish"},            // formerly ji
	{'yo', "Yoruba"},
	{'za', "Zhuang"},
	{'zh', "Chinese"},
	{'zu', "Zulu"},
   { 0, NULL}
};

LPCTSTR IfoDecodeLang(WORD descr)
{
   int i;
   static TCHAR msg[20];

   for (i = 0; lang_tbl[i].lang_long; i++) {
     if (descr == lang_tbl[i].descr) {
                  return lang_tbl[i].lang_long;
          }
   }

   sprintf(msg, "Unknow (0x%02x%02x)", (descr>>8)&0xff, descr&0xff);
   return msg;
}
