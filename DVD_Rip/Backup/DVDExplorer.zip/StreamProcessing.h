// StreamProcessing.h: interface for the CStreamProcessing class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STREAMPROCESSING_H__51BC674D_19D9_4716_96CF_8FB18A583270__INCLUDED_)
#define AFX_STREAMPROCESSING_H__51BC674D_19D9_4716_96CF_8FB18A583270__INCLUDED_

#include "Stream.h"
#include <afxtempl.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CStreamProcessing  
{
public:
	CStreamProcessing();
	virtual ~CStreamProcessing();

   void DeleteAllStream();

   CList<CStream*, CStream*> Stream; 
   CStream *AddStream();

   unsigned char Enabled;
};

#endif // !defined(AFX_STREAMPROCESSING_H__51BC674D_19D9_4716_96CF_8FB18A583270__INCLUDED_)
