// TimeMapTable.cpp: implementation of the CTimeMapTable class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TimeMapTable.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CTimeMapTable::CTimeMapTable()
{
   pLBA = NULL;
   LBAcnt = 0;
   Step = -1;
}

CTimeMapTable::~CTimeMapTable()
{
   if (pLBA) delete[] pLBA;
}
/////////////////////////////////////////////////////////////////////////////
//

unsigned long *CTimeMapTable::NewLBA(int cnt)
{
   if (pLBA) delete[] pLBA;
   pLBA = (unsigned long*)new long[cnt];
   LBAcnt = cnt;
   return pLBA;
}
