// Angle.cpp: implementation of the CAngle class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Utilities.h"
#include "Angle.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CAngle::CAngle(int number, int title)
{
   CAngle::number = number;
   CAngle::Title = title;
   Length = 0.0;
   Size = 0;
   LBAStart = 0;
   LBAStop = 0;
   AverageDatarate = 0;
   MinDatarate = ULONG_MAX;
   MaxDatarate = 0;
   SelectedChapters = -1;
   SelectedCells = -1;
}

CAngle::~CAngle()
{
   while (!Chapter.IsEmpty()) delete Chapter.RemoveHead();
}
/////////////////////////////////////////////////////////////////////////////
//

void CAngle::Calculate()
{
   Length = 0.0;
   Size = 0;
   LBAStart = ULONG_MAX;
   LBAStop = 0;
   AverageDatarate = 0;
   MinDatarate = ULONG_MAX;
   MaxDatarate = 0;
   SelectedChapters = 0;
   SelectedCells = 0;

   // for all CCells of all CChapters
   POSITION pch = Chapter.GetHeadPosition();
   while (pch) {
      CChapter *pChapter = Chapter.GetNext(pch);
      int select = 0;

      pChapter->Calculate();
      POSITION pce = pChapter->Cell.GetHeadPosition();
      while (pce) {
         CCell *pCell = pChapter->Cell.GetNext(pce);
         if (pCell->IsSelected()) {
            SelectedCells++;
            select = 1;
            Length += pCell->Length;
            Size += pCell->Size;
            if (pCell->LBAStart < LBAStart) LBAStart = pCell->LBAStart;
            if (pCell->LBAStop > LBAStop) LBAStop = pCell->LBAStop;
            if (pCell->MinDatarate < MinDatarate) MinDatarate = pCell->MinDatarate;
            if (pCell->MaxDatarate > MaxDatarate) MaxDatarate = pCell->MaxDatarate;
         }
      }
      SelectedChapters += select;
   }
   if (MinDatarate == ULONG_MAX) MinDatarate = 0;
   if (Length > 0.0) AverageDatarate = unsigned long(double(Size) * 2048.0 / Length);
}
/////////////////////////////////////////////////////////////////////////////
//

CChapter *CAngle::AddChapter()
{
   CChapter *tmp = new CChapter(Chapter.GetCount());
   if (tmp) Chapter.AddTail(tmp);
   return tmp;
}
/////////////////////////////////////////////////////////////////////////////
//

void CAngle::Select()
{
   POSITION pos = Chapter.GetHeadPosition();
   while (pos) Chapter.GetNext(pos)->Select();
}
/////////////////////////////////////////////////////////////////////////////
//

void CAngle::UnSelect()
{
   POSITION pos = Chapter.GetHeadPosition();
   while (pos) Chapter.GetNext(pos)->UnSelect();
}
/////////////////////////////////////////////////////////////////////////////
//

CString CAngle::Name()
{
   CString msg;
   msg.Format("Angle %d [%s]", number+1, msDecode(Length * 1000, false));
   return msg;
}
