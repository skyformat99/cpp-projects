// DVDExplorerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DVDExplorer.h"
#include "DirPickDlg.h"
//#include "Play.h"
#include "DVDExplorerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDVDExpDlg dialog

CDVDExpDlg::CDVDExpDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDVDExpDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDVDExpDlg)
	m_edtFile = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

   m_iml.Create(IDB_BICONS, 16, 0, COLORREF(0x00FF00FF));
   m_ichk.Create(IDB_BCHECK, 16, 0, COLORREF(0x00FF00FF));
}

void CDVDExpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDVDExpDlg)
	DDX_Control(pDX, IDC_TREE_TITLE, m_treeTitle);
	DDX_Control(pDX, IDC_LST_VIDEOINFO, m_lstVideoInfo);
	DDX_Control(pDX, IDC_LST_TOTALSEL, m_lstTotalSel);
	DDX_Control(pDX, IDC_LST_STREAMS, m_lstStreams);
	DDX_Control(pDX, IDC_LST_SELCHAPTER, m_lstSelChapter);
	DDX_Control(pDX, IDC_LST_CHAPTERS, m_lstChapters);
	DDX_Control(pDX, IDC_LST_CELLS, m_lstCells);
	DDX_Text(pDX, IDC_EDT_FILE, m_edtFile);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDVDExpDlg, CDialog)
	//{{AFX_MSG_MAP(CDVDExpDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_FILE, OnBtnFile)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE_TITLE, OnSelchangedTreeTitle)
	ON_NOTIFY(NM_CLICK, IDC_LST_CHAPTERS, OnClickLstChapters)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BTN_ERROR, OnBtnError)
	ON_NOTIFY(NM_CLICK, IDC_LST_CELLS, OnClickLstCells)
	ON_BN_CLICKED(IDC_BTN_DVD, OnBtnDvd)
	//}}AFX_MSG_MAP
   ON_WM_DROPFILES()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDVDExpDlg message handlers

BOOL CDVDExpDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL) {
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty()) {
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

   // decor of button
   ((CButton*)GetDlgItem(IDC_BTN_DVD))->SetIcon(AfxGetApp()->LoadIcon(IDI_DVD));

   // Initialize the Tree and List boxes
   m_treeTitle.SetImageList(&m_iml, TVSIL_NORMAL);

//   m_lstChapters.SetExtendedStyle(LVS_EX_CHECKBOXES);
   m_lstChapters.SetImageList(&m_ichk, LVSIL_STATE);
   m_lstChapters.InsertColumn(0, "", LVCFMT_LEFT);

   m_lstCells.SetExtendedStyle(LVS_EX_CHECKBOXES);
//   m_lstCells.SetImageList(&m_ichk, LVSIL_STATE);
   m_lstCells.InsertColumn(0, "", LVCFMT_LEFT);

   m_lstTotalSel.SetExtendedStyle(LVS_EX_FULLROWSELECT);
   m_lstTotalSel.InsertColumn(0, "", LVCFMT_LEFT);
   m_lstTotalSel.InsertColumn(1, "", LVCFMT_LEFT);
   DVD.TotalSelUpdate(&m_lstTotalSel);

   m_lstSelChapter.SetExtendedStyle(LVS_EX_FULLROWSELECT);
   m_lstSelChapter.InsertColumn(0, "", LVCFMT_LEFT);
   m_lstSelChapter.InsertColumn(1, "", LVCFMT_LEFT);
   DVD.SelChapterUpdate(&m_lstSelChapter);

   m_lstVideoInfo.SetExtendedStyle(LVS_EX_FULLROWSELECT);
   m_lstVideoInfo.InsertColumn(0, "", LVCFMT_LEFT);
   m_lstVideoInfo.InsertColumn(1, "", LVCFMT_LEFT);
   DVD.VideoInfoUpdate(&m_lstVideoInfo);

//   m_lstStreams.SetExtendedStyle(LVS_EX_CHECKBOXES);
//   m_lstStreams.SetImageList(&m_ichk, LVSIL_STATE);
   m_lstStreams.InsertColumn(0, "", LVCFMT_LEFT);
   m_lstStreams.SetImageList(&m_iml, LVSIL_SMALL);

   // Enable drag/drop open
	DragAcceptFiles();

   // to first DVD read
   m_timer = SetTimer(1, 5, NULL);

   return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDVDExpDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX) {
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
   } else {
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDVDExpDlg::OnPaint() 
{
	if (IsIconic()) {
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM)dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
   } else {
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDVDExpDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CDVDExpDlg::OnBtnDvd() 
{
   DVDSearchAndRead();
}

void CDVDExpDlg::OnBtnFile() 
{
   CDirPickDlg dlg(this);

   UpdateData();
   dlg.m_selected = m_edtFile;
   if (dlg.DoModal() == IDOK) DVDRead(dlg.m_selected);
}

void CDVDExpDlg::OnSelchangedTreeTitle(NMHDR* pNMHDR, LRESULT* pResult) 
{
   DVD.TreeChange(&m_treeTitle);
   DVD.ChaptersUpdate(&m_lstChapters);
   DVD.TotalSelUpdate(&m_lstTotalSel);
   DVD.VideoInfoUpdate(&m_lstVideoInfo);
   DVD.ShowStreamInfo(&m_lstStreams);

   DVD.SelChapterUpdate(&m_lstSelChapter);
   DVD.CellsUpdate(&m_lstCells);
	if (pResult) *pResult = 0;
}

void CDVDExpDlg::OnClickLstChapters(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
   if (pNMListView->ptAction.x < 14) {
      // update of item state (check bits)
      UINT state = m_lstChapters.GetItemState(pNMListView->iItem, -1);
      DVD.ChaptersSetCheck(pNMListView->iItem, state);
      DVD.ChaptersCheckUpdate(&m_lstChapters);
   }
   DVD.ChapterSelected(&m_lstChapters);
   DVD.CellsUpdate(&m_lstCells);
   DVD.Calculate();
   DVD.TotalSelUpdate(&m_lstTotalSel);
   DVD.SelChapterUpdate(&m_lstSelChapter);
	
	*pResult = 1;           // to stop a update of ItemState
}

void CDVDExpDlg::OnClickLstCells(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
   if (pNMListView->ptAction.x < 14) {
      // update of item state (check bits)
//      UINT state = m_lstCells.GetItemState(pNMListView->iItem, -1);
      m_lstCells.SetCheck(pNMListView->iItem, !m_lstCells.GetCheck(pNMListView->iItem));
      DVD.CellsCheck(&m_lstCells);
      DVD.ChaptersCheckUpdate(&m_lstChapters);
   }
   DVD.CellsSelected(&m_lstCells);
   DVD.Calculate();
   DVD.TotalSelUpdate(&m_lstTotalSel);
   DVD.SelChapterUpdate(&m_lstSelChapter);

	*pResult = 1;           // to stop a update of ItemState
}

void CDVDExpDlg::OnTimer(UINT nIDEvent) 
{  
   KillTimer(m_timer);
   DVDSearchAndRead();
}

void CDVDExpDlg::OnBtnError() 
{
   CStringList *pErrMsg = DVD.ErrorMsg();
   if (pErrMsg) {
      CErrorDlg dlg(pErrMsg);
      dlg.DoModal();
   } else {
      MessageBox("Not error");
   }
}

// default drop processing will attempt to open the file
void CDVDExpDlg::OnDropFiles(HDROP hDropInfo)
{
   UINT nFiles = ::DragQueryFile(hDropInfo, (UINT)-1, NULL, 0);

   if (nFiles == 1) {
      TCHAR szFileName[MAX_PATH];
      ::DragQueryFile(hDropInfo, 0, szFileName, MAX_PATH);

      DVDRead(szFileName);
   }
   ::DragFinish(hDropInfo);
}
/////////////////////////////////////////////////////////////////////////////
// Read the selected DVD

void CDVDExpDlg::DVDRead(CString path)
{
   m_edtFile = path;
   UpdateData(FALSE);
   DVD.Clean();
   DVD.SetPath(path);
   DVD.ReadVMG_IFO();
   DVD.FindIFO();

   if (DVD.MovieTreeUpdate(&m_treeTitle)) {
      SetWindowText("DVDExplorer : " + DVD.GetTitle());

      GetDlgItem(IDC_BTN_ERROR)->EnableWindow(DVD.ErrorMsg() != NULL);
   } else {
      // movie not found
      OnSelchangedTreeTitle(NULL, NULL);
      SetWindowText("DVDExplorer");
      MessageBox("Invalid directory !", NULL, MB_ICONERROR);
   }
}

void CDVDExpDlg::DVDSearchAndRead()
{
   for (;;) {
      if (DVD.SearchDVDDrive()) {
         DVDRead(DVD.GetPath());
         break;
      } else if (MessageBox("DVD not found !", NULL, MB_RETRYCANCEL|MB_ICONERROR)
         != IDRETRY) {
         break;
      }
   }
}
