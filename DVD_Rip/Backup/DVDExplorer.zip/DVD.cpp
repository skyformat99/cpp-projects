// DVD.cpp: implementation of the CDVD class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Utilities.h"
#include "IfoRecords.h"
#include "IfoUtilities.h"
#include <Shlwapi.h>

#include "DVD.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CDVD::CDVD()
{
   pSelMovie   = NULL;
   pSelAngle   = NULL;
   pSelChapter = NULL;
   pSelCell    = NULL;
   pVMG        = NULL;

   srcIsDvd    = false;

   diskRL = 2048;
}

CDVD::~CDVD()
{
   Clean();
}

void CDVD::Clean()
{
   errMsg.RemoveAll();
   while (!Movie.IsEmpty()) delete Movie.RemoveHead();
   srcIsDvd = false;
   if (pVMG) delete pVMG;
   pVMG = NULL;
}
/////////////////////////////////////////////////////////////////////////////
// Search a DVD with movie on the system

BOOL CDVD::SearchDVDDrive() // Return: 0=no Error
{
   DWORD dw = ::GetLogicalDrives() >> 3;  // skip A:, B:, C:
   TCHAR driveName[] = "D:";              // perhaps, the first DVD drive ?
   TCHAR pathName[MAX_PATH];
   TCHAR volumeName[40];
   TCHAR FileSystemNameBuffer[40];
   DWORD MaxComponent = 0;
   DWORD FileSystemFlags = 0;
   WIN32_FIND_DATA fd;
   HANDLE hd;
   
   while ( dw ) {
      if ( dw & 1 ) {
         FileSystemNameBuffer[0] = volumeName[0] = 0;
         ::GetVolumeInformation(driveName, volumeName, 40, NULL,
            &MaxComponent, &FileSystemFlags, FileSystemNameBuffer, 40);

         if ( strcmp(FileSystemNameBuffer, "UDF") == 0      // DVD
           || strcmp(FileSystemNameBuffer, "CDFS") == 0) { // CD
            // It's a DVD file system

            ::PathCombine(pathName, driveName, "VIDEO_TS\\*.IFO");
            hd = ::FindFirstFile(pathName, &fd);
            if ( hd != INVALID_HANDLE_VALUE ) {
               // This perhaps a movie DVD

               ::FindClose(hd);

               ::PathRemoveFileSpec(pathName);
               Path = pathName;
               Title = volumeName;
               srcIsDvd = true;
               return TRUE;
            }
         }
      }

      // next drive
      driveName[0]++, dw >>= 1;
   }
   return FALSE;
}
////////////////////////////////////////////////////////////////////////////
// Initialize a new path for the movie

BOOL CDVD::SetPath(CString &path)
{
   TCHAR pathName[MAX_PATH];
   TCHAR volumeName[40] = "";
   TCHAR FileSystemNameBuffer[40];
   DWORD MaxComponent;
   DWORD FileSystemFlags;

   strcpy(pathName, path);
   srcIsDvd = false;
   // remove a last back slash
   int len = strlen(pathName) - 1;
   if (pathName[len] == '\\') pathName[len] = 0;

   if (::PathRemoveFileSpec(pathName)) {
      if (::PathIsRoot(pathName)) {

         ::GetVolumeInformation(pathName, volumeName, 40, NULL,
            &MaxComponent, &FileSystemFlags, FileSystemNameBuffer, 40);

         Title = volumeName;
         Path = path;
         srcIsDvd = true;
      } else {
         Title = ::PathFindFileName(path);

         Path = path;
         if (Title.CompareNoCase("VIDEO_TS") == 0)
            Title = ::PathFindFileName(pathName);
      }
      return TRUE;

   } else if (pathName[strlen(pathName) - 1] == ':') {

      ::GetVolumeInformation(pathName, volumeName, 40, NULL,
         &MaxComponent, &FileSystemFlags, FileSystemNameBuffer, 40);

      ::PathAppend(pathName, "VIDEO_TS");

      Title = volumeName;
      Path = pathName;
      srcIsDvd = true;
      return TRUE;
   }

   Path = path;
   Title = "Movie";

   return FALSE;
}
////////////////////////////////////////////////////////////////////////////
// Read VIDEO_TS.IFO file

BOOL CDVD::ReadVMG_IFO()
{
   TCHAR fname[MAX_PATH];
   CMovie movie(&errMsg);
   CIFO ifo(&errMsg);

   ::PathCombine(fname, Path, "video_ts.ifo");
   ifo.Read(fname, &movie);
   return ((pVMG = ifo.GetVmg()) != NULL);
}
////////////////////////////////////////////////////////////////////////////
//

CMovie *CDVD::AddMovie()
{
    CMovie *tmp = new CMovie(&errMsg);
    if (tmp) Movie.AddTail(tmp);
    return tmp;
}
/////////////////////////////////////////////////////////////////////////////
// Computs a movie BDD

void CDVD::FindIFO()
{
   TCHAR fname[MAX_PATH];
   WIN32_FIND_DATA fd;
   CString name;
   HANDLE hd;
   short i;

   // Clear the movie list
   while (!Movie.IsEmpty()) delete Movie.RemoveHead();

   // search the valid entries
	for (i = 1; i < IFOCOUNTER; i++) {

      name.Format("vts_%02d_*.vob", i);
      ::PathCombine(fname, Path, name);
      hd = ::FindFirstFile(fname, &fd);
      if ( hd != INVALID_HANDLE_VALUE ) {
         ::FindClose(hd);

         // make a tree of the movie DVD
         CMovie *pMovie = AddMovie();

         pMovie->ParseIFOFile(Path, i);
         pMovie->Video.Calculate();
		}
	}
}

void CDVD::Calculate()
{
   if (pSelMovie) pSelMovie->Video.Calculate();
}
/////////////////////////////////////////////////////////////////////////////
// Updates a movie tree

BOOL CDVD::MovieTreeUpdate(CTreeCtrl *pTreeCtrl)
{
   pSelAngle = NULL;
   pSelMovie = NULL;
   pSelChapter = NULL;
   pTreeCtrl->DeleteAllItems();

   // make a tree of the movie DVD
   unsigned long greatest = 0;
   HTREEITEM hMovie = NULL, htiSave = NULL;
   POSITION mpo = Movie.GetHeadPosition();
   while (mpo) {
      CMovie *pMovie = Movie.GetNext(mpo);

      hMovie = pTreeCtrl->InsertItem(pMovie->GetName(), 4, 4);
      pTreeCtrl->SetItemData(hMovie, DWORD(pMovie));

      POSITION pti = pMovie->Video.Title.GetHeadPosition();
      while (pti) {
         CTitle *pTitle = pMovie->Video.Title.GetNext(pti);

         HTREEITEM hTitle = pTreeCtrl->InsertItem(pTitle->Name(), 5, 5, hMovie);
         pTreeCtrl->SetItemData(hTitle, DWORD(pTitle));

         POSITION pan = pTitle->Angle.GetHeadPosition();
         while (pan) {
            CAngle *pAngle = pTitle->Angle.GetNext(pan);

            HTREEITEM hAngle = pTreeCtrl->InsertItem(pAngle->Name(), 7, 7, hTitle);
            pTreeCtrl->SetItemData(hAngle, DWORD(pAngle));

            if (pAngle->Size > greatest) {
               // the greatest angle
               greatest = pAngle->Size;
               htiSave = hAngle;
		      }
         }
      }
   } // end for loop

   if (htiSave != NULL) {
      HTREEITEM hTitle = pTreeCtrl->GetParentItem(htiSave);
      HTREEITEM hMovie = pTreeCtrl->GetParentItem(hTitle);

      // Select the greatest
      pTreeCtrl->SelectItem(htiSave);
//      pTreeCtrl->Expand(hMovie, TVE_EXPAND);
      pSelAngle = (CAngle*)pTreeCtrl->GetItemData(htiSave);
      pSelMovie = (CMovie*)pTreeCtrl->GetItemData(hMovie);
      pSelMovie->StreamProcess();
      return TRUE;
   }
   return FALSE;
}
/////////////////////////////////////////////////////////////////////////////
// Select in a tree

void CDVD::TreeChange(CTreeCtrl *pTreeCtrl)
{
   HTREEITEM hTree, hSelItem = pTreeCtrl->GetSelectedItem();

   pSelAngle = NULL;
   pSelMovie = NULL;
   pSelChapter= NULL;
   if (hSelItem) {

      switch (pTreeCtrl->GetItemText(hSelItem)[0]) {
      case 'A' :     // Angle
         hTree = pTreeCtrl->GetParentItem(pTreeCtrl->GetParentItem(hSelItem));
         pSelAngle = (CAngle*)pTreeCtrl->GetItemData(hSelItem);
         pSelMovie = (CMovie*)pTreeCtrl->GetItemData(hTree);
         break;
      case 'P' :     // Program
         hTree = pTreeCtrl->GetParentItem(hSelItem);
         pSelMovie = (CMovie*)pTreeCtrl->GetItemData(hTree);
         break;
//      case 'T' :     // Title
//         pSelMovie = (CMovie*)pTreeCtrl->GetItemData(hSelItem);
//         break;
      }

      if (pSelMovie) pSelMovie->StreamProcess();
   }
}
/////////////////////////////////////////////////////////////////////////////
//

void CDVD::VideoInfoUpdate(CListCtrl *pLstVideoInfo)
{
   pLstVideoInfo->DeleteAllItems();
   pLstVideoInfo->InsertItem(0, "Compression");
   pLstVideoInfo->InsertItem(1, "TVsystem");
   pLstVideoInfo->InsertItem(2, "AspectRatio");
   pLstVideoInfo->InsertItem(3, "Pan/scan");
   pLstVideoInfo->InsertItem(4, "SourceRes");
   pLstVideoInfo->InsertItem(5, "Letterboxed");
   pLstVideoInfo->InsertItem(6, "Mode");
   pLstVideoInfo->SetColumnWidth(0, LVSCW_AUTOSIZE);

   if (pSelMovie) {

      // Video info
      pLstVideoInfo->SetItemText(0, 1, pSelMovie->Video.Compression);
      pLstVideoInfo->SetItemText(1, 1, pSelMovie->Video.TVsystem);
      pLstVideoInfo->SetItemText(2, 1, pSelMovie->Video.AspectRatio);
      pLstVideoInfo->SetItemText(3, 1, pSelMovie->Video.DisplayMode);
      pLstVideoInfo->SetItemText(4, 1, pSelMovie->Video.SourceRes);
      pLstVideoInfo->SetItemText(5, 1, pSelMovie->Video.Letterboxed);
      pLstVideoInfo->SetItemText(6, 1, pSelMovie->Video.Mode);
      if (pVMG) {

         pLstVideoInfo->InsertItem(7, "Volume");
         pLstVideoInfo->InsertItem(8, "Region");
         pLstVideoInfo->SetItemText(7, 1, toString(pVMG->Volume, pVMG->VolumesCount, true));
         pLstVideoInfo->SetItemText(8, 1, getZones(pVMG->RegionMask));
      }
      pLstVideoInfo->SetColumnWidth(1, LVSCW_AUTOSIZE);
   }
}
/////////////////////////////////////////////////////////////////////////////
//

void CDVD::ChaptersUpdate(CListCtrl *pLstChapters)
{
   pLstChapters->DeleteAllItems();
   pSelChapter = NULL;
   pSelCell = NULL;
   CellCount = 0;

   if (pSelAngle) {
      POSITION pos = pSelAngle->Chapter.GetHeadPosition();
      while (pos) {
         CChapter *pChapter = pSelAngle->Chapter.GetNext(pos);

         CellCount += pChapter->Cell.GetCount();

         int item = pLstChapters->InsertItem(0xFFFF, pChapter->Name());
         pLstChapters->SetItemState(item, pChapter->Selected(), LVIS_STATECHKMASK);
         pLstChapters->SetItemData(item, DWORD(pChapter));
         ASSERT(pChapter->number == item);
      }
      pLstChapters->SetColumnWidth(0, LVSCW_AUTOSIZE);

      if (pLstChapters->GetItemCount()) {
         // Select the first item
         pLstChapters->SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
         pSelChapter = (CChapter*)pLstChapters->GetItemData(0);
      }
   }
}

void CDVD::ChaptersCheckUpdate(CListCtrl *pLstChapters)
{
   if (pSelAngle) {
      POSITION pos = pSelAngle->Chapter.GetHeadPosition();
      while (pos) {
         CChapter *pChapter = pSelAngle->Chapter.GetNext(pos);

         pLstChapters->SetItemState(pChapter->number, pChapter->Selected(), LVIS_STATECHKMASK);
      }
   }
}

void CDVD::ChaptersSetCheck(int item, UINT state)
{
   if (pSelAngle) {
      POSITION pos = pSelAngle->Chapter.FindIndex(item);
      if (pos) {
         CChapter *pChapter = pSelAngle->Chapter.GetAt(pos);
         ASSERT(item == pChapter->number);

         if (state & LVIS_STATECHK) pChapter->UnSelect();
         else pChapter->Select();
      }
   }
}
/////////////////////////////////////////////////////////////////////////////
//

void CDVD::ChapterSelected(CListCtrl *pLstChapters)
{
   POSITION pos = pLstChapters->GetFirstSelectedItemPosition();
   if (pos && pSelAngle) {
      int selected = pLstChapters->GetNextSelectedItem(pos);
      pSelChapter = pSelAngle->GetChapterAt(selected);
   } else {
      pSelChapter = NULL;
   }
   pSelCell = NULL;
}
/////////////////////////////////////////////////////////////////////////////
//

void CDVD::CellsUpdate(CListCtrl *pLstCells)
{
   pLstCells->DeleteAllItems();

   if (pSelChapter) {

      POSITION pos = pSelChapter->Cell.GetHeadPosition();
      while (pos) {
         CCell *pCell = pSelChapter->Cell.GetNext(pos);

         int no = pLstCells->InsertItem(0xFFFF, pCell->Name());
         pLstCells->SetCheck(no, pCell->IsSelected());
         pLstCells->SetItemData(no, DWORD(pCell));
         ASSERT(no == pCell->number);
      }
      pLstCells->SetColumnWidth(0, LVSCW_AUTOSIZE);

   }
}

void CDVD::CellsCheckUpdate(CListCtrl *pLstCells)
{
   if (pSelChapter) {

      POSITION pos = pSelChapter->Cell.GetHeadPosition();
      while (pos) {
         CCell *pCell = pSelChapter->Cell.GetNext(pos);

         pLstCells->SetCheck(pCell->number, pCell->IsSelected());
      }
   }
}

void CDVD::CellsCheck(CListCtrl *pLstCells)
{
   if (pSelChapter) {
      POSITION pos = pSelChapter->Cell.GetHeadPosition();
      while (pos) {
         CCell *pCell = pSelChapter->Cell.GetNext(pos);

         if (pLstCells->GetCheck(pCell->number)) pCell->Select();
         else pCell->UnSelect();
      }
   }
}

void CDVD::CellsSelected(CListCtrl *pLstCells)
{
   pSelCell = NULL;
   if (pSelChapter) {
      POSITION pos = pLstCells->GetFirstSelectedItemPosition();
      if (pos) {
         int item = pLstCells->GetNextSelectedItem(pos);
         pSelCell = (CCell*)pLstCells->GetItemData(item);
      }
   }
}
/////////////////////////////////////////////////////////////////////////////
//

void CDVD::SelChapterUpdate(CListCtrl *pLstSelChapter)
{
   pLstSelChapter->DeleteAllItems();
   pLstSelChapter->InsertItem(0, "Size");
   pLstSelChapter->InsertItem(1, "Length");
   pLstSelChapter->InsertItem(2, "LBA-Start");
   pLstSelChapter->InsertItem(3, "LBA-Stop");
   pLstSelChapter->InsertItem(4, "Cells");
   pLstSelChapter->InsertItem(5, "minDatarate");
   pLstSelChapter->InsertItem(6, "maxDatarate");
   pLstSelChapter->InsertItem(7, "avqDatarate");
   pLstSelChapter->SetColumnWidth(0, LVSCW_AUTOSIZE);

   if (pSelChapter) {
      if (pSelCell) {

         CString sIds;
         sIds.Format("v_%d  c_%d", pSelCell->VobID, pSelCell->CellID);

         // show selected cell info
         pLstSelChapter->SetItemText(0, 1, LBA2Byte(pSelCell->Size,10));
         pLstSelChapter->SetItemText(1, 1, sec2Time(pSelCell->Length));
         pLstSelChapter->SetItemText(2, 1, toString(pSelCell->LBAStart));
         pLstSelChapter->SetItemText(3, 1, toString(pSelCell->LBAStop));
         pLstSelChapter->SetItemText(4, 0, "IDs");
         pLstSelChapter->SetItemText(4, 1, sIds);
         pLstSelChapter->SetItemText(5, 1, Value2Rate(pSelCell->MinDatarate,10));
         pLstSelChapter->SetItemText(6, 1, Value2Rate(pSelCell->MaxDatarate,10));
         pLstSelChapter->SetItemText(7, 1, Value2Rate(pSelCell->AverageDatarate,10));
      } else {

         // show selected chapter info
         pLstSelChapter->SetItemText(0, 1, LBA2Byte(pSelChapter->Size,10));
         pLstSelChapter->SetItemText(1, 1, sec2Time(pSelChapter->Length));
         pLstSelChapter->SetItemText(2, 1, toString(pSelChapter->LBAStart));
         pLstSelChapter->SetItemText(3, 1, toString(pSelChapter->LBAStop));
         pLstSelChapter->SetItemText(4, 1, toString(pSelChapter->GetSelectedCellCount(),
                                                      pSelChapter->Cell.GetCount()));
         pLstSelChapter->SetItemText(5, 1, Value2Rate(pSelChapter->MinDatarate,10));
         pLstSelChapter->SetItemText(6, 1, Value2Rate(pSelChapter->MaxDatarate,10));
         pLstSelChapter->SetItemText(7, 1, Value2Rate(pSelChapter->AverageDatarate,10));
      }
      pLstSelChapter->SetColumnWidth(1, LVSCW_AUTOSIZE);
   }

}
/////////////////////////////////////////////////////////////////////////////
//

void CDVD::TotalSelUpdate(CListCtrl *pLstTotalSel)
{
   pLstTotalSel->DeleteAllItems();
   pLstTotalSel->InsertItem(0, "Size");
   pLstTotalSel->InsertItem(1, "Length");
   pLstTotalSel->InsertItem(2, "Chapters");
   pLstTotalSel->InsertItem(3, "Cells");
   pLstTotalSel->InsertItem(4, "minDatarate");
   pLstTotalSel->InsertItem(5, "maxDatarate");
   pLstTotalSel->InsertItem(6, "avqDatarate");
   pLstTotalSel->SetColumnWidth(0, LVSCW_AUTOSIZE);

   if (pSelAngle) {

      if (pSelMovie->CheckSize(pSelAngle->Size)) {
         pLstTotalSel->SetItemText(0, 1, LBA2Byte(pSelAngle->Size,10));
      } else {
         pLstTotalSel->SetItemText(0, 1, LBA2Byte(pSelAngle->Size,10) + "?");
         errMsg.AddTail("Size incompatible with VOB file detected");
      }

      pLstTotalSel->SetItemText(1, 1, sec2Time(pSelAngle->Length));
      pLstTotalSel->SetItemText(2, 1, toString(pSelAngle->GetSelectedChapterCount(),
                                                pSelAngle->Chapter.GetCount()));
      pLstTotalSel->SetItemText(3, 1, toString(pSelAngle->GetSelectedCellCount(), CellCount));
      pLstTotalSel->SetItemText(4, 1, Value2Rate(pSelAngle->MinDatarate, 10));
      pLstTotalSel->SetItemText(5, 1, Value2Rate(pSelAngle->MaxDatarate, 10));
      pLstTotalSel->SetItemText(6, 1, Value2Rate(pSelAngle->AverageDatarate,10));
/*
      CString msg;
      pLstTotalSel->InsertItem(7, "no-min");
      msg.Format("%d/%d", Movie.GetHead()->lba, Movie.GetHead()->lbamx);
      pLstTotalSel->SetItemText(7, 1, msg);
*/
      pLstTotalSel->SetColumnWidth(1, LVSCW_AUTOSIZE);
   }
}
/////////////////////////////////////////////////////////////////////////////
// Stream info

void CDVD::ShowStreamInfo(CListCtrl *pLstStreams)
{
   pLstStreams->DeleteAllItems();

   if (pSelMovie) {
      POSITION pos = pSelMovie->StreamProcessing.Stream.GetHeadPosition();
      while (pos) {
         CStream *pStream = pSelMovie->StreamProcessing.Stream.GetNext(pos);

         int no = pLstStreams->InsertItem(0xFFFF, pStream->Name, pStream->Type);
         pLstStreams->SetItemState(no, (pStream->Checked << 12) + 0x5000, LVIS_STATEIMAGEMASK);

//         if (pStream->Checked) pLstStreams->SetCheck(no);
      }

      pLstStreams->SetColumnWidth(0, LVSCW_AUTOSIZE);
   }
}
/////////////////////////////////////////////////////////////////////////////
// IFO and VOB file names

void CDVD::FilesListUpdate(CListCtrl *pLstFiles, bool all)
{
   pLstFiles->DeleteAllItems();

   if (!all && pSelMovie) {
      FilesListUpdate(pLstFiles, pSelMovie);
   } else {
      if (pVMG) {
         int no = pLstFiles->InsertItem(0xFFFF, "video_ts.ifo", 8);
         pLstFiles->SetItemText(no, 1, Value2KB(pVMG->ifoLength / 1024));
         pLstFiles->SetCheck(no);
      }
      POSITION pmv = Movie.GetHeadPosition();
      while (pmv) FilesListUpdate(pLstFiles, Movie.GetNext(pmv));
   }
   if (pLstFiles->GetStyle() & LVS_REPORT) {
      pLstFiles->SetColumnWidth(0, LVSCW_AUTOSIZE);
      pLstFiles->SetColumnWidth(1, LVSCW_AUTOSIZE);
   }
}

void CDVD::FilesListUpdate(CListCtrl *pLstFiles, CMovie *pMovie)
{
   // IFO filename
   int no = pLstFiles->InsertItem(0xFFFF, pMovie->GetIfoName(), 8);
   pLstFiles->SetItemText(no, 1, Value2KB(pMovie->IfoSize / 1024));
   pLstFiles->SetCheck(no);

   // VOBs filenames
   POSITION pvb = pMovie->VOB.GetHeadPosition();
   while (pvb) {
      t_VOB &vob = pMovie->VOB.GetNext(pvb);

      no = pLstFiles->InsertItem(0xFFFF, pMovie->GetVobFile(&vob), 6);
      pLstFiles->SetItemText(no, 1, Value2KB(DWORD(vob.size / 1024)));
      if (vob.checked) pLstFiles->SetCheck(no);
   }
}
/////////////////////////////////////////////////////////////////////////////
// Disk space

_int64 CDVD::FreeSpace(LPCTSTR path)
{
   TCHAR rpath[MAX_PATH];
   DWORD SectorsPerCluster;
   DWORD BytesPerSector;
   DWORD NumberOfFreeClusters;
   DWORD TotalNumberOfClusters;

   strcpy(rpath, path);
   ::PathStripToRoot(rpath);
   ::GetDiskFreeSpace(rpath, &SectorsPerCluster, &BytesPerSector,
                       &NumberOfFreeClusters, &TotalNumberOfClusters);

   diskRL = BytesPerSector * SectorsPerCluster;
   return _int64(diskRL) * NumberOfFreeClusters;
}

_int64 CDVD::VobSize(CMovie *pMovie, DWORD record, bool all)
{
   _int64 space = 0;
   POSITION pvb = pMovie->VOB.GetHeadPosition();
   while (pvb) {
      t_VOB &vob = pMovie->VOB.GetNext(pvb);

      // space for the corresponding "vts_xx_n.vob" files
      if (all || vob.checked) space += Round(vob.size, record);
   }
   TRACE("CDVD::VobSize %d size=%d\n", pMovie->VOB.GetCount(), DWORD(space/0x400));
   return space;
}

_int64 CDVD::RequiredSpace(CMovie *pMovie, DWORD record, bool all)
{
   return Round(pMovie->IfoSize, record) + VobSize(pMovie, record, all);
}

_int64 CDVD::RequiredSpace(bool all, DWORD record)
{
   _int64 space = 0;

   if (record == 0) record = diskRL;

   if (!all && pSelMovie) {

      space = RequiredSpace(pSelMovie, record, false);
   } else {
      // required space for the full DVD movie

      // space for the "video_ts.ifo" file
      if (pVMG) space += Round(pVMG->ifoLength, record);

      // space for the movies files ("vts_xx_0.ifo" and "vts_xx_*.vob" files) 
      POSITION pmv = Movie.GetHeadPosition();
      while (pmv) space += RequiredSpace(Movie.GetNext(pmv), record, true);
   }
   return space;
}
