// Unit.cpp: implementation of the CUnit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Unit.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CUnit::CUnit(int number)
{
   CUnit::number = number;
   TotalPlayTime = 0;
   Length = 0.0;
   Size = 0;
   AngleCounter = 0;

   pCellLink = NULL;
   CellLinkCnt = 0;
}

CUnit::~CUnit()
{
   if (pCellLink) delete[] pCellLink;
   while(!Cell.IsEmpty()) delete Cell.RemoveHead();
}
/////////////////////////////////////////////////////////////////////////////
// Create a new CellLink table

unsigned char *CUnit::NewCellLink(int count)
{
   if (pCellLink) delete[] pCellLink;

   CellLinkCnt = count;
   pCellLink = (unsigned char*)new char[count];
   return pCellLink;
}
/////////////////////////////////////////////////////////////////////////////
// Add a CCell element at the Cell list

CCell *CUnit::AddCell( unsigned char ChainInfo,
                       unsigned short VobID, unsigned short CellID,
                       unsigned long LBAStart, unsigned long LBAStop,
                           double Length )
{
   CCell *tmp = new CCell(Cell.GetCount());
   if (tmp) {
      tmp->ChainInfo = ChainInfo;
      tmp->VobID = VobID;
      tmp->CellID = CellID;
      tmp->LBAStart = LBAStart;
      tmp->LBAStop = LBAStop;
      tmp->Length = Length;
      tmp->Size = (LBAStop > LBAStart)? LBAStop - LBAStart + 1 : 0;
      Cell.AddTail(tmp);
   }
   return tmp;
}
/////////////////////////////////////////////////////////////////////////////
//

void CUnit::Calculate()
{
   Length = 0.0;
   Size = 0;
   POSITION pos = Cell.GetHeadPosition();
   while (pos) {
      CCell *pCell = Cell.GetNext(pos);

      Length += pCell->Length;
      Size   += pCell->Size;
   }
}
