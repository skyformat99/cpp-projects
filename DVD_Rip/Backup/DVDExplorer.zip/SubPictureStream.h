// SubPictureStream.h: interface for the CSubPictureStream class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SUBPICTURESTREAM_H__B93B1542_A74B_4974_95C6_C1364F9C2C37__INCLUDED_)
#define AFX_SUBPICTURESTREAM_H__B93B1542_A74B_4974_95C6_C1364F9C2C37__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSubPictureStream  
{
public:
	CSubPictureStream();
	virtual ~CSubPictureStream();

   unsigned char ID;          // 0xBD
   unsigned char SubID;       // 0x2x,0x3x
   CString Language;          // English, Deutsch,...
   CString Caption;
};

#endif // !defined(AFX_SUBPICTURESTREAM_H__B93B1542_A74B_4974_95C6_C1364F9C2C37__INCLUDED_)
