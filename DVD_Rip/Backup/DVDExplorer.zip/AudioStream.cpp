// AudioStream.cpp: implementation of the CAudioStream class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "AudioStream.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAudioStream::CAudioStream()
{
   ID = 0;           // 0xBD,0xC0,0xC8
   SubID = 0;        // 0x8x,0xA0
   Audio_Mode = 0;   // Index Audioformat
}

CAudioStream::~CAudioStream()
{
}
