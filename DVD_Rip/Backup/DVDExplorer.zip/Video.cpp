// Video.cpp: implementation of the CVideo class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Video.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CVideo::CVideo()
{
   MovieTitle  = 0;
}

CVideo::~CVideo()
{
   while (!Title.IsEmpty()) delete Title.RemoveHead();
}
/////////////////////////////////////////////////////////////////////////////
//

void CVideo::Calculate()
{
   POSITION pos = Title.GetHeadPosition();
   while (pos) Title.GetNext(pos)->Calculate();
}
/////////////////////////////////////////////////////////////////////////////
//

CTitle *CVideo::AddTitle()
{
    CTitle *tmp = new CTitle(Title.GetCount());
    if (tmp) Title.AddTail(tmp);
    return tmp;
}
