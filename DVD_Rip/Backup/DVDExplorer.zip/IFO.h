// IFO.h: interface for the CIFO class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IFO_H__25CABA23_E0A3_40CE_8B39_B76AC07C5F0D__INCLUDED_)
#define AFX_IFO_H__25CABA23_E0A3_40CE_8B39_B76AC07C5F0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMovie;

typedef struct {
   BYTE RegionMask;
   BYTE sideId;
   WORD VolumesCount;
   WORD Volume;
   WORD TitlesCount;
   DWORD ifoLength;
} t_VMG;


class CIFO  
{
private:
   CFile file;                // IFO file
   PBYTE buffers[10];         // buffer ptrs
   DWORD bLength[10];
   unsigned char vtsVmg;
   CMovie *pMovie;
   CStringList *pErrMsg;

   int ReadTbl(unsigned long ofs, int tblId);
   void DecodeVideo();
   void DecodeAudio(DWORD ofs);
   void GetSubPictureStream(DWORD ofs);
   void GetPgc(class CUnit *pUnit, PBYTE pgc);
   void GetTmt();
   void GetTitlePgci();
   void GetCellAddr();
   void GetVtsmVobuAddrMap();
   void GetVtsVobuAddrMap();
   void Error(LPCTSTR lpszFormat, ...);
public:

	CIFO(CStringList *pErrMsg);
	virtual ~CIFO();

   void Read(LPCTSTR fileName, CMovie *pMovie);
   t_VMG *GetVmg();
};

#endif // !defined(AFX_IFO_H__25CABA23_E0A3_40CE_8B39_B76AC07C5F0D__INCLUDED_)
