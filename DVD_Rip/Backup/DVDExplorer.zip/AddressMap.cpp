// AddressMap.cpp: implementation of the CAddressMap class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "AddressMap.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CAddressMap::CAddressMap()
{
   pLBA = NULL;
   LBAcnt = 0;
}

CAddressMap::~CAddressMap()
{
   if (pLBA) delete[] pLBA;
}
/////////////////////////////////////////////////////////////////////////////
//

unsigned long *CAddressMap::NewLBA(int cnt)
{
   if (pLBA) delete[] pLBA;

   pLBA = (unsigned long*)new long[cnt];
   LBAcnt = cnt;
   return pLBA;
}
