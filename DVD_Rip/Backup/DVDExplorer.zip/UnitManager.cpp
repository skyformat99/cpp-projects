// UnitManager.cpp: implementation of the CUnitManager class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UnitManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CUnitManager::CUnitManager()
{
}

CUnitManager::~CUnitManager()
{
   while (!Unit.IsEmpty()) delete Unit.RemoveHead();
   while (!TSCA.IsEmpty()) delete TSCA.RemoveHead();
}
/////////////////////////////////////////////////////////////////////////////
//

void CUnitManager::Calculate()
{
   POSITION pos = Unit.GetHeadPosition();
   while (pos) Unit.GetNext(pos)->Calculate();
}
/////////////////////////////////////////////////////////////////////////////
//

CUnit *CUnitManager::AddUnit()
{
   CUnit *tmp = new CUnit(Unit.GetCount());
   if (tmp) Unit.AddTail(tmp);
   return  tmp;
}
/////////////////////////////////////////////////////////////////////////////
//

CCell *CUnitManager::AddTSCACell( unsigned short VobID, unsigned short CellID,
                           unsigned long LBAStart, unsigned long LBAStop)
{
   CCell *tmp = new CCell(TSCA.GetCount());
   if (tmp) {
      tmp->Position = 0;
      tmp->VobID    = VobID;
      tmp->CellID   = CellID;
      tmp->LBAStart = LBAStart;
      tmp->LBAStop  = LBAStop;
      tmp->Size     = LBAStop - LBAStart + 1;

      TSCA.AddTail(tmp);

      TRACE("CUnitManager::AddTSCACell VobID=%d CellID=%d\n", VobID, CellID);
   }
   return tmp;
}
