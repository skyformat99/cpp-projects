// TimeMapTable.h: interface for the CTimeMapTable class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TIMEMAPTABLE_H__E4578953_F1B4_4685_9524_EE1E710DCE48__INCLUDED_)
#define AFX_TIMEMAPTABLE_H__E4578953_F1B4_4685_9524_EE1E710DCE48__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTimeMapTable  
{
private:
   int LBAcnt;
public:
	CTimeMapTable();
	virtual ~CTimeMapTable();

   long Step;         // 1,2,3,4 sec

   unsigned long *pLBA;
   inline int GetLBAcnt() { return LBAcnt; }
   unsigned long *NewLBA(int cnt);
};

#endif // !defined(AFX_TIMEMAPTABLE_H__E4578953_F1B4_4685_9524_EE1E710DCE48__INCLUDED_)
