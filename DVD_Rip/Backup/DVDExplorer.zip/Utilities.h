// Utilities.h: interface for the Utilities class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UTILITIES_H__90716EF0_CE76_4805_AC79_111DA93D10C5__INCLUDED_)
#define AFX_UTILITIES_H__90716EF0_CE76_4805_AC79_111DA93D10C5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define IFOCOUNTER 99
#define VOBCOUNTER 99

extern _int64 GetFileLength(LPCTSTR path);
extern inline _int64 Round(_int64 length, DWORD rl);

extern CString msDecode(double time, bool ms);
extern CString msDecode(unsigned long time, bool ms);

extern CString toString(unsigned long val, unsigned long max = 0, bool fract = false);
extern CString Value2Byte(unsigned int Value,unsigned int overdrive);
extern CString Value2KB(unsigned int Value);    // KB=>1.000.123 KB
extern CString LBA2Byte(unsigned int Value,unsigned int overdrive);
extern CString Value2Rate(unsigned int Value, unsigned int overdrive);
extern CString sec2Time(double sec);
extern CString getZones(BYTE z);

#endif // !defined(AFX_UTILITIES_H__90716EF0_CE76_4805_AC79_111DA93D10C5__INCLUDED_)
