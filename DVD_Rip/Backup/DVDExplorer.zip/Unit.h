// Unit.h: interface for the CUnit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UNIT_H__1199D8F5_D39A_4270_8F2B_1D9121753BD4__INCLUDED_)
#define AFX_UNIT_H__1199D8F5_D39A_4270_8F2B_1D9121753BD4__INCLUDED_

#include "Cell.h"
#include <afxtempl.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CUnit  
{
private:
   int CellLinkCnt;
   unsigned char *pCellLink;
public:
	CUnit(int number);
	virtual ~CUnit();

   unsigned char *NewCellLink(int count);
   inline int GetCellLinkCount() { return CellLinkCnt; }
   inline unsigned char GetCellLink(int n) { return pCellLink[n]; }

   CList<CCell*, CCell*> Cell;
   CCell *GetCellAt(int i) { return Cell.GetAt(Cell.FindIndex(i)); }
   CCell *AddCell(unsigned char ChainInfo,
                  unsigned short VobID, unsigned short CellID,
                  unsigned long LBAStart, unsigned long LBAStop,
                           double Length);
   void Calculate();

   int number;                // unit number
   double TotalPlayTime;      // Length of Unit in sec
   double Length;             // sum of CellLength in sec
   unsigned long Size;        // in LBA
   unsigned int AngleCounter;
};

#endif // !defined(AFX_UNIT_H__1199D8F5_D39A_4270_8F2B_1D9121753BD4__INCLUDED_)
