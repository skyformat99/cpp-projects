// Audio.h: interface for the CAudio class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AUDIO_H__505AF890_5B1F_4BB6_829A_7BEBA75C62B3__INCLUDED_)
#define AFX_AUDIO_H__505AF890_5B1F_4BB6_829A_7BEBA75C62B3__INCLUDED_

#include "AudioStream.h"
#include <afxtempl.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAudio  
{
public:
	CAudio();
	virtual ~CAudio();

   char Avail[8];

   CList<CAudioStream*, CAudioStream*> AudioStream;

   CAudioStream *AddAudioStream();
};

#endif // !defined(AFX_AUDIO_H__505AF890_5B1F_4BB6_829A_7BEBA75C62B3__INCLUDED_)
