// Title.cpp: implementation of the CTitle class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Title.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CTitle::CTitle(int number)
{
   CTitle::number = number + 1;
}

CTitle::~CTitle()
{
   while (!Angle.IsEmpty()) delete Angle.RemoveHead();
}
/////////////////////////////////////////////////////////////////////////////
//

void CTitle::Calculate()
{
   POSITION pos = Angle.GetHeadPosition();
   while (pos) Angle.GetNext(pos)->Calculate();
}
/////////////////////////////////////////////////////////////////////////////
//

CAngle *CTitle::AddAngle()
{
   CAngle *tmp = new CAngle(Angle.GetCount(), number);
   if (tmp) Angle.AddTail(tmp);
   return tmp;
}
/////////////////////////////////////////////////////////////////////////////
//

CString CTitle::Name()
{
   CString name;
   name.Format("Program Chain %d", number);
   return name;
}