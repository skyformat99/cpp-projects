// IfoRecords.h: interface for the IfoRecords class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IFORECORDS_H__0DA37BA4_0291_447E_8DAC_6FADA648B7C0__INCLUDED_)
#define AFX_IFORECORDS_H__0DA37BA4_0291_447E_8DAC_6FADA648B7C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma pack(push)
#pragma pack(1)

#define IFO_SUBPIC_SIZE    6
#define IFO_SUBPICSUB_SIZE 6
#define DVD_VIDEO_LB_LEN   2048

   // records types
typedef enum { ID_MAT, ID_PTT_SRPT, ID_PGCI, ID_M_PGCI_UT, ID_TMAPTI,
               ID_MENU_CELL_ADDR, ID_MENU_VOBU_ADDR_MAP, ID_TITLE_CELL_ADDR,
               ID_TITLE_VOBU_ADDR_MAP };
//
// Video Info Table 
//
typedef struct {
   unsigned int letterBox     : 1; // 1 = disallowed
   unsigned int panScan       : 1; // 1 = disallowed
   unsigned int aspectRatio   : 2; // 0 = 4:3, 1,2 = reserved, 3 = 16:9
   unsigned int standard      : 2; // 0 = NTSC, 1 = PAL
   unsigned int codingMode    : 2; // 0 = Mpeg-1, 1 = Mpeg-2

   unsigned int cameraFilm    : 1; // If Standard = PAL : 0 = camera, 1 = film
   unsigned int unknown       : 1;
   unsigned int letterBoxed   : 1; // 1 = Letterboxed
   unsigned int resolution    : 3; // Resolution NTSC (PAL) 0 = 720x480 (720x576)
                                   //                       1 = 704x480 (704x576)
                                   //                       2 = 352x480 (352x576)
                                   //                       3 = 352x240 (352x288)
   unsigned int line21_1      : 1; // CC for line 21 field 2 in GOP (NTSC only)
   unsigned int line21_2      : 1; // CC for line 21 field 1 in GOP (NTSC only)
} t_IfoVideoAttribut;              // sizeof = 2
//
// Audio info table
//
typedef struct {
	unsigned int appl_mode     : 2;
	unsigned int type          : 2;
	unsigned int multichannel  : 1;
	unsigned int coding_mode   : 3;

	unsigned int num_channels  : 3;
	unsigned int               : 1;
	unsigned int sample_freq   : 2;
	unsigned int quantization  : 2;

   unsigned int lang_code     :16;  // <2 char> description

	unsigned char foo;               // 0x00 ?
	unsigned char caption;
	unsigned char bar;               // 0x00 ?
   unsigned char sup;               // karaoke or suround
} t_IfoAudioAttribut;               // sizeof = 8

#pragma pack(pop)


#endif // !defined(AFX_IFORECORDS_H__0DA37BA4_0291_447E_8DAC_6FADA648B7C0__INCLUDED_)
