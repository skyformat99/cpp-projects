// Title.h: interface for the CTitle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TITLE_H__FD5CD295_5676_4E6D_BB87_66286F660D09__INCLUDED_)
#define AFX_TITLE_H__FD5CD295_5676_4E6D_BB87_66286F660D09__INCLUDED_

#include "Angle.h"
#include <afxtempl.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTitle  
{
private:
   int number;

public:
	CTitle(int number);
	virtual ~CTitle();

   CList<CAngle*, CAngle*> Angle;
   CAngle *AddAngle();

   void Calculate();
   CString Name();
};

#endif // !defined(AFX_TITLE_H__FD5CD295_5676_4E6D_BB87_66286F660D09__INCLUDED_)
