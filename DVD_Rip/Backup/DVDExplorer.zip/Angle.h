// Angle.h: interface for the CAngle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ANGLE_H__097753A4_835D_4332_B7E8_D52D62CD663A__INCLUDED_)
#define AFX_ANGLE_H__097753A4_835D_4332_B7E8_D52D62CD663A__INCLUDED_

#include "Chapter.h"
#include <afxtempl.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAngle  
{
private:
   int SelectedChapters;
   int SelectedCells;
   int Title;
   int number;

public:
	CAngle(int number, int title);
	virtual ~CAngle();

   CList<CChapter*, CChapter*> Chapter;
   CChapter *GetChapterAt(int i) { return Chapter.GetAt(Chapter.FindIndex(i)); }
   CChapter *AddChapter();
   inline int GetSelectedCellCount() { return SelectedCells; }
   inline int GetSelectedChapterCount() { return SelectedChapters; }

   double TotalPlayTime;         // a copy of um->unit
   double Length;                // in sec
   unsigned long Size;           // in LBA
   unsigned long LBAStart;
   unsigned long LBAStop;
   unsigned long AverageDatarate;
   unsigned long MinDatarate;
   unsigned long MaxDatarate;

   void Calculate();
   void Select();
   void UnSelect();
   CString Name();
};

#endif // !defined(AFX_ANGLE_H__097753A4_835D_4332_B7E8_D52D62CD663A__INCLUDED_)
