// IFO.cpp: implementation of the CIFO class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Movie.h"
#include "IfoRecords.h"
#include "IfoUtilities.h"
#include "IFO.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

////////////// IFO files "VTS_tt_v.IFO" record 0x800 offsets ////////////////

   // table of Titles and Chapters
#define OFF_VTS_PTT_SRPT         get4Bytes(buffers[ID_MAT] + 0xC8) // VTS_PTT_SRPT
   // Title Program Chain table
#define OFF_VTS_PGCI             get4Bytes(buffers[ID_MAT] + 0xCC) // VTS_PGCI
   // Menu Program Chain table
#define OFF_VTSM_PGCI_UT         get4Bytes(buffers[ID_MAT] + 0xD0) // VTSM_PGCI_UT
   // time map
#define OFF_TMAPTI               get4Bytes(buffers[ID_MAT] + 0xD4) // VTS_TMAPTI
   // menu cell address table
#define OFF_MENU_CELL_ADDR       get4Bytes(buffers[ID_MAT] + 0xD8) // VTSM_C_ADT
   // menu VOBU address map
#define OFF_MENU_VOBU_ADDR_MAP   get4Bytes(buffers[ID_MAT] + 0xDC) // VTSM_VOBU_ADMAP
   // title set cell address table
#define OFF_TITLE_CELL_ADDR      get4Bytes(buffers[ID_MAT] + 0xE0) // VTS_C_ADT
   // title set VOBU address map
#define OFF_TITLE_VOBU_ADDR_MAP  get4Bytes(buffers[ID_MAT] + 0xE4) // VTS_VOBU_ADMAP

/////////////////////////////////////////////////////////////////////////////

///////////// IFO file "VIDEO_TS.IF" record 0x800 offsets ///////////////////

   //
#define OFF_VMG_PTT              get4Bytes(buffers[ID_MAT] + 0xC4)
   //
#define OFF_VMG_MENU_PGCI        get4Bytes(buffers[ID_MAT] + 0xC8)
   //
#define OFF_VMG_TMT              get4Bytes(buffers[ID_MAT] + 0xD0)

/////////////////////////////////////////////////////////////////////////////

#define OFFSET_IFO               0x0000
#define OFFSET_VTS               0x0000
#define OFFSET_LEN               0x00C0
#define IFO_OFFSET_TAT           0x00C0
#define OFFSET_VTSI_MAT          0x0080
#define IFO_OFFSET_VIDEO         0x0100
#define IFO_OFFSET_AUDIO         0x0200
#define IFO_OFFSET_SUBPIC        0x0250

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CIFO::CIFO(CStringList *pErrMsg)
{
   CIFO::pErrMsg = pErrMsg;
   for (int i = 0; i < 10; i++) buffers[i] = NULL;
   vtsVmg = 0;
}

CIFO::~CIFO()
{
   for (int i = 0; i < 10; i++) if (buffers[i]) free(buffers[i]);
}
/////////////////////////////////////////////////////////////////////////////
// Read IFO

void CIFO::Read(LPCTSTR fileName, CMovie *pMovie)
{
   CIFO::pMovie = pMovie;

   vtsVmg = 0;
   if (!file.Open(fileName, CFile::modeRead)) {
      Error("file open error");
   } else if (ReadTbl(0, ID_MAT) == 0) {
      pMovie->IfoSize = DWORD(file.GetLength());

//**      DWORD numMenuVobs = get4Bytes(buffers[ID_MAT] + 0xC0);
//**      TRACE("CIFO::Read m=%08x %s\n", numMenuVobs, file.GetFileName());

      if (strncmp((char*)buffers[ID_MAT], "DVDVIDEO-VTS", 12) == 0) {
         vtsVmg = 2;

//**		   ReadTbl(OFF_VTS_PTT_SRPT,          ID_PTT_SRPT);
		   ReadTbl(OFF_VTS_PGCI,            ID_PGCI);
//**		   ReadTbl(OFF_VTSM_PGCI_UT,           ID_M_PGCI_UT);
         ReadTbl(OFF_TMAPTI,              ID_TMAPTI);
//**		   ReadTbl(OFF_MENU_CELL_ADDR,      ID_MENU_CELL_ADDR);
//**		   ReadTbl(OFF_MENU_VOBU_ADDR_MAP,  ID_MENU_VOBU_ADDR_MAP);
		   ReadTbl(OFF_TITLE_CELL_ADDR,     ID_TITLE_CELL_ADDR);
		   ReadTbl(OFF_TITLE_VOBU_ADDR_MAP, ID_TITLE_VOBU_ADDR_MAP);

      } else if (strncmp((char*)buffers[ID_MAT], "DVDVIDEO-VMG", 12) == 0) {
         // this part is not in use
         vtsVmg = 1;


//**		   IfoReadTbl(OFF_VMG_PTT,             ID_PTT_SRPT);
   //		IfoReadTbl(OFF_VMG_PGCI,          ID_PGCI);
//**		   IfoReadTbl(OFF_VMG_MENU_PGCI,       ID_M_PGCI_UT);
//**		   IfoReadTbl(OFF_VMG_TMT,             ID_TMT);
   //		IfoReadTbl(OFF_MENU_CELL_ADDR,      ID_MENU_CELL_ADDR);
   //		IfoReadTbl(OFF_MENU_VOBU_ADDR_MAP,  ID_MENU_VOBU_ADDR_MAP);
//**        ReadTbl(OFF_TITLE_CELL_ADDR,     ID_TITLE_CELL_ADDR);
//**        IfoReadTbl(OFF_TITLE_VOBU_ADDR_MAP, ID_TITLE_VOBU_ADDR_MAP);

      } else {
         Error("IFO Hdr error");
      }
      file.Close();
   }

   DecodeVideo();

   switch(vtsVmg) {
   case 2 :    // vts
      DecodeAudio(0x202);
      GetSubPictureStream(0x254);
      GetTmt();
      break;
   case 1 :    // vmg
      break;
   }

   GetTitlePgci();
   GetCellAddr();
   GetVtsVobuAddrMap();
}
/////////////////////////////////////////////////////////////////////////////
// Read IFO record(s)

int CIFO::ReadTbl(unsigned long ofs, int tblId)
{
   DWORD len = DVD_VIDEO_LB_LEN, ofsLen = ofs * len, rdLen, rqLen;
   DWORD max = (file.GetLength() > ofsLen)? DWORD(file.GetLength()) - ofsLen: 0;
   PBYTE data;

   if (max == 0 || (ofsLen == 0 && tblId != 0)) {
      Error("null record entry in %s", recordName[tblId]);
      return 1;
   }

   data = (PBYTE)calloc(len, 1);
   if (data == NULL) {
      return 2;
   }

   file.Seek(ofsLen, CFile::begin);
   rdLen = file.Read(data, len);

   switch (tblId) {
   case ID_MAT :
      rqLen = len = DVD_VIDEO_LB_LEN;
      break;
   case ID_TITLE_VOBU_ADDR_MAP:
   case ID_MENU_VOBU_ADDR_MAP:
	   rqLen = len = get4Bytes(data);
	   break;

   default:
	   rqLen = len = get4Bytes(data + 4);
   }

   if (len > max) len = max;

	if (len > DVD_VIDEO_LB_LEN) {
      free(data);
		data =  (PBYTE)calloc(len, 1);
      if (data == NULL) {
         return 3;
      }
      file.Seek(ofs * DVD_VIDEO_LB_LEN, CFile::begin);
      rdLen = file.Read(data, len);
   }

   bLength[tblId] = len;
   buffers[tblId] = data;
/*
   TRACE("ifoReadTbl %d l=%06x: %02x %02x %02x %02x %02x %02x %02x %02x "
                        " %02x %02x %02x %02x %02x %02x %02x %02x\n", tblId, len,
      data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7],
      data[len-8], data[len-7], data[len-6], data[len-5],
      data[len-4], data[len-3], data[len-2], data[len-1]);
*/
   if (len > rdLen) {
      Error("Eof error record %s (%d/%d)", recordName[tblId], len, rdLen);
      return 4;
   }
   return 0;
}
/////////////////////////////////////////////////////////////////////////////
// Set error message

void CIFO::Error(LPCTSTR lpszFormat, ...)
{
   CString error, fmt;
   va_list pa;

   // add a fileName at the format...
   fmt.Format("%s : %s", file.GetFileName(), lpszFormat);
   va_start(pa, lpszFormat);

   // formats the error message and push it
   error.FormatV(fmt, pa);
   pErrMsg->AddTail(error);
}
/////////////////////////////////////////////////////////////////////////////
// Get VMG data

t_VMG *CIFO::GetVmg()
{
   PBYTE ptr;
   if (vtsVmg == 1 && (ptr = buffers[ID_MAT])) {
      t_VMG *pVmg = new t_VMG;
      if (pVmg) {
         pVmg->RegionMask  = ptr[0x23];
         pVmg->sideId      = ptr[0x2A];
         pVmg->VolumesCount= get2Bytes(ptr + 0x26);
         pVmg->Volume      = get2Bytes(ptr + 0x28);
         pVmg->TitlesCount = get2Bytes(ptr + 0x3E);
         pVmg->ifoLength   = pMovie->IfoSize;
         return pVmg;
      }
   }
   return NULL;
}
/////////////////////////////////////////////////////////////////////////////
// Video info

void CIFO::DecodeVideo()
{
   PBYTE ptr = buffers[ID_MAT];
   if (ptr == NULL) return;

   const LPCTSTR compression[2] = {
      "MPEG 1", "MPEG 2"
   };
	const LPCTSTR letterBoxes[4] = {
		"no", "no", "auto", "not auto"
	};
	const LPCTSTR sourceRes[2][4] = {
      {"720x480", "704x480", "352x480", "352x240"},
      {"720x576", "704x576", "352x576", "352x288"}
	};
   const LPCTSTR systemTV[2] = {
      "NTSC", "PAL"
   };
   const LPCTSTR aspectRatio[4] = {
      "4:3", "reserved1", "reserved2", "16:9"
   };
   const LPCTSTR mode[2][2] = {
      {"", ""}, {"camera", "film"}
   };
   const LPCTSTR dataInGop[2][2] = {
      {"", "data present"}, {"", ""}
   };

   t_IfoVideoAttribut *pVideo = (t_IfoVideoAttribut*)(ptr + 0x100);
   unsigned short codingMode = pVideo->codingMode;
   unsigned short standard   = pVideo->standard;
   unsigned short letterBox  = pVideo->letterBox + pVideo->letterBoxed * 2;

   pMovie->Video.Compression  = compression[codingMode];
   pMovie->Video.TVsystem     = systemTV[standard];
   pMovie->Video.AspectRatio  = aspectRatio[pVideo->aspectRatio];
   pMovie->Video.DisplayMode  = pVideo->panScan? "no": "yes";
   pMovie->Video.Line211      = dataInGop[standard][pVideo->line21_1];
   pMovie->Video.Line212      = dataInGop[standard][pVideo->line21_2];
   pMovie->Video.SourceRes    = sourceRes[standard][pVideo->resolution];
   pMovie->Video.Letterboxed  = letterBoxes[letterBox];
   pMovie->Video.Mode         = mode[standard][pVideo->cameraFilm];
}
/////////////////////////////////////////////////////////////////////////////
// Audio info

void CIFO::DecodeAudio(DWORD ofs)
{
   PBYTE ptr = buffers[ID_MAT];
   if (ptr == NULL || ofs == 0) return;

   const LPCTSTR quantization[] = {
      "16bit", "20bit", "24bit", ""
   };  
	const LPCTSTR codingMode[8] = {
      "AC3", "???", "MPEG1", "MPEG2ext", "LPCM", "???", "DTS", "SDDS"
	};
	const LPCTSTR applicationMode[4] = {
      "", "karaoke", "surround", ""
	};
   const LPCTSTR codeExtension[8] = {
      "", "normal", "visually impaired", "director's comments",
      "alternate director's comments", "", "", ""
   };

   unsigned short i, num = get2Bytes(ptr + ofs);   // number of audio streams
   t_IfoAudioAttribut *pAudio = (t_IfoAudioAttribut*)(ptr + ofs + 2);
	for (i = 0; i < num; i++, pAudio++) {
      CAudioStream *pAudioStream = pMovie->Audio.AddAudioStream();

      pAudioStream->Language = IfoDecodeLang(swap16(pAudio->lang_code));

      switch(pAudioStream->Audio_Mode = pAudio->coding_mode) {
      case 0:
         pAudioStream->ID    = 0xBD;
         pAudioStream->SubID = 0x80 + i;
         break;
      case 1:
         pAudioStream->ID    = 0xBD;      // ???
         pAudioStream->SubID = 0x80 + i;  // ???
         break;
      case 2:
         pAudioStream->ID    = 0xC0+i;
         pAudioStream->SubID = 0;
         break;
      case 3:
         pAudioStream->ID    = 0xC8 + i;
         pAudioStream->SubID = 0;
         break;
      case 4:
         pAudioStream->ID    = 0xBD;
         pAudioStream->SubID = 0xA0 + i;
         break;
      case 5:
         pAudioStream->ID    = 0xBD;
         pAudioStream->SubID = 0x88 + i;
         break;
      case 6:
         pAudioStream->ID    = 0xBD;
         pAudioStream->SubID = 0x88 + i;
         break;
      case 7:
         pAudioStream->ID    = 0xBD;     // ???
         pAudioStream->SubID = 0x88 + i;// ???
         break;
      }

      pAudioStream->Mode.Format("%s(%dCh)%s",
                                 codingMode[pAudio->coding_mode],
                                         pAudio->num_channels + 1,
                              pAudio->multichannel? "+multichannel": "");

      pAudioStream->Frequenz     = pAudio->sample_freq? "96kHz": "48kHz";
      pAudioStream->Quantization = quantization[pAudio->quantization];
		pAudioStream->ApplMode     = applicationMode[pAudio->appl_mode];
      pAudioStream->Caption      = codeExtension[pAudio->caption & 0x07];
	}
}
/////////////////////////////////////////////////////////////////////////////
// Subpicture info

void CIFO::GetSubPictureStream(DWORD ofs)
{
   const LPCTSTR langExt[16] = {
      "", "normal", "large", "children",
      "", "normal captions", "large captions", "childrens captions",
      "", "forced", "", "",
      "", "director comments", "large director comments", "director comments for children"
   };

   PBYTE ptr = buffers[ID_MAT];
   if (ptr == NULL || ofs == 0) return;

   // number of subpicture streams
   unsigned short i, num = get2Bytes(ptr + ofs);
   PBYTE pSPS = ptr + ofs + 2;
   for (i = 0; i < num; i++, pSPS += IFO_SUBPICSUB_SIZE) {
      CSubPictureStream *pSps = pMovie->SubPicture.AddSubPictureStream(0xBD, 0x20 + i);

      if ((pSPS[0] & 0x03) == 1)
         pSps->Language = IfoDecodeLang(get2Bytes(pSPS + 2));
      if (pSPS[5] < 16)
         pSps->Caption  = langExt[pSPS[5]];
	}
}
/////////////////////////////////////////////////////////////////////////////
// VTS_TMAPTI (time map)
//    This table contains time maps for each PGC

void CIFO::GetTmt()
{
   PBYTE ptr = buffers[ID_TMAPTI];
   if (ptr) {
      DWORD length = bLength[ID_TMAPTI];
      // number of program chains
      WORD n, num = get2Bytes(ptr);
      // end address (last byte of last VTS_TMAP)
      DWORD endAddr = get4Bytes(ptr + 0x04);

      if (endAddr > length) {
         endAddr = length;
         Error("Length error in %s", recordName[ID_TMAPTI]);
      }
      
      for (n = 0; n < num; n++) {
         // offset to VTS_TMAP 1
         PBYTE pHDR = ptr + get4Bytes(ptr + 0x08 + n * 4);
         // Note: each PGC MUST have a time map, even if it is empty
         PBYTE pEnd = ptr + ((n + 1 == num)? endAddr + 1:
                                  get4Bytes(ptr + 0x08 + n * 4 + 4));

         PBYTE pTMAP = pHDR + 4;
         if (pEnd > pTMAP) {
            // step time
            pMovie->pTmt->Step = pHDR[0];
            // number of entries in map 0 for empty map
            WORD w = get2Bytes(pHDR + 2);
            //
            int len = (pEnd - pTMAP) / 4;

            unsigned long *pLba = pMovie->pTmt->NewLBA(len + 1);
            *pLba++ = 0;
            for (int i = 0; i < len; i++, pTMAP += 4)
               *pLba++ = get4Bytes(pTMAP) & 0x7FFFFFFF;

            break;      // ??
         }
      }
   }
}
/////////////////////////////////////////////////////////////////////////////
// Read Program Chain structure (PGC)

void CIFO::GetPgc(CUnit *pUnit, PBYTE pgc)
{
   unsigned char i;

   // playback time, BCD, hh:mm:ss:ff with bits 7&6 of frame (last) byte indicating frame rate 

   pUnit->TotalPlayTime = BCDtime(pgc + 0x04);

   // PGC_AST_CTL - Audio Stream Control, each entry

   char number = char(pUnit->number);
   PBYTE pAudio = pgc + 0x0C;
	for (i = 0; i < 8; i++, pAudio += 2) {		// 8 subaudio streams
		if (*pAudio & 0x80) pMovie->Audio.Avail[*pAudio & 0x07] = number;
	}

   // PGC_SPST_CTL - Subpicture Stream Control, each entry

   PBYTE pSpic = pgc + 0x1C;
	for (i = 0; i < 32; i++, pSpic += 4) {
		if (*pSpic & 0x80) {	// avail
         // Stream number for 4:3
         pMovie->SubPicture.Avail[pSpic[0] & 0x1f] = number;
         // Stream number for wide
         pMovie->SubPicture.Avail[pSpic[1] & 0x1f] = number;
         // Stream number for letterbox
         pMovie->SubPicture.Avail[pSpic[2] & 0x1f] = number;
         // Stream number for pan&scan
         pMovie->SubPicture.Avail[pSpic[3] & 0x1f] = number;
		}
	}

   // get counters
	BYTE progsCnt = pgc[0x02];    // number of programs
   BYTE cellsCnt = pgc[0x03];    // number of cells

   // pgc + get2Bytes(pgc + 0xE4); // addr of PGC commands (not use)

   // program map entry (one per program)

   // addr of PGC program map
   PBYTE pLink = pgc + get2Bytes(pgc + 0xE6);
   unsigned char *pCellLink = pUnit->NewCellLink(progsCnt);
   for (i = 0; i < progsCnt; i++) *pCellLink++ = pLink[i];

   // cell position & playback information table entry (one per cell)

   // addr of PGC cell position information table
   PBYTE pCellPos = pgc + get2Bytes(pgc + 0xEA);
   // addr of PGC cell playback information table
   PBYTE pCellAddr = pgc + get2Bytes(pgc + 0xE8);
   int VOB_id, Cell_id, oc = 0, ov = 0;
   for (i = 0; i < cellsCnt; i++, pCellPos += 0x04, pCellAddr += 0x18) {

      VOB_id  = get2Bytes(pCellPos);               // VOB_id and Cell_id
      Cell_id = pCellPos[3];                       // pCellPos[2] : reserved

      if (VOB_id  == 0) VOB_id  = ov + 1;          // automatic calcul
      if (Cell_id == 0) Cell_id = oc + 1;

      pUnit->AddCell( pCellAddr[0],                // chain info
                      ov = VOB_id,
                      oc = Cell_id,
                      get4Bytes(pCellAddr + 0x08), // VOBU start sector
                      get4Bytes(pCellAddr + 0x14), // last VOBU end sector
                      BCDtime(pCellAddr + 0x04) ); // cell playback time
   }
}
/////////////////////////////////////////////////////////////////////////////
// VTS_PGCI (Title Program Chain table)
//    The VTS_PGCI contains a list of Program Chains (PGCs), and the PGCs themselves

void CIFO::GetTitlePgci()
{
   PBYTE ptr = buffers[ID_PGCI];
   if (ptr) {
      CUnitManager *pUm = pMovie->pUm;
      // number of Program Chains
      WORD i, num = get2Bytes(ptr);
      // end address (last byte of last PGC) relative to VTS_PGCI
      DWORD endAddr = get4Bytes(ptr + 0x04);

      PBYTE pPgci = ptr + 0x08;
	   for (i = 0; i < num; i++, pPgci += 0x08) {
         BYTE id = pPgci[0];                 // title number 
         WORD pmm = get2Bytes(pPgci + 0x02); // parental management mask
         DWORD ofs = get4Bytes(pPgci + 0x04);// offset to VTS_PGC, relative to VTS_PGCI
         TRACE("CIFO::GetTitlePgci n=%d ofs=%d id=%02x pmm=%04x\n", i, ofs, id);

         GetPgc(pUm->AddUnit(), ptr + ofs);
	   }
   }
}
/////////////////////////////////////////////////////////////////////////////
// VTS_C_ADT (title set cell address table)

void CIFO::GetCellAddr()
{
   PBYTE ptr = buffers[ID_TITLE_CELL_ADDR];
   if (ptr) {
      DWORD length = bLength[ID_TITLE_CELL_ADDR];
      DWORD counter = get4Bytes(ptr + 0x04);
      CUnitManager *pUm = pMovie->pUm;
      PBYTE pCellAddr = ptr + 0x08;
      unsigned short i;

      if (counter > length) {
         counter = length;
         Error("Length error in %s", recordName[ID_TITLE_CELL_ADDR]);
      }
      counter = (counter - 7) / 0x0C;

	   for (i = 0; i < counter; i++, pCellAddr += 0x0C) {
         pUm->AddTSCACell(
                  get2Bytes(pCellAddr),   // VOBidn - Video Object Identifier
                  pCellAddr[2],           // CELLidn - cell id, pCellAddr[3] don't know
               get4Bytes(pCellAddr + 4),  // starting sector within VOB
               get4Bytes(pCellAddr + 8) );// ending sector within VOB
	   }
   }
}
/////////////////////////////////////////////////////////////////////////////
// Read VTSM_VOBU_ADMAP

void CIFO::GetVtsmVobuAddrMap()
{
   PBYTE ptr = buffers[ID_MENU_VOBU_ADDR_MAP];
	unsigned int i, num, length = bLength[ID_MENU_VOBU_ADDR_MAP];
   if (ptr == NULL) return;

	num = get4Bytes(ptr);
   if (num > length) {
      num = length;
      Error("Length error in %s", recordName[ID_MENU_VOBU_ADDR_MAP]);
   }
   num = (num - 3) / 4;
	ptr += 4;

   // VIDEO OBJECT ADDRESS MAP

   TRACE("CIFO::GetVtsmVobuAddrMap %d\n", num);
   unsigned long *pLBA = pMovie->pAm->NewLBA(num);
   for (i = 0; i < num; i++, ptr += 4) {
      *pLBA++ = get4Bytes(ptr);
   }
}
/////////////////////////////////////////////////////////////////////////////
// Read VTS_VOBU_ADMAP

void CIFO::GetVtsVobuAddrMap()
{
   PBYTE ptr = buffers[ID_TITLE_VOBU_ADDR_MAP];
   unsigned int i, num, length = bLength[ID_TITLE_VOBU_ADDR_MAP];
   if (ptr == NULL) return;

	num = get4Bytes(ptr);
   if (num > length) {
      num = length;
      Error("Length error in %s", recordName[ID_TITLE_VOBU_ADDR_MAP]);
   }
   num = (num - 3) / 4;
	ptr += 4;

   // VIDEO OBJECT ADDRESS MAP;

   TRACE("CIFO::GetVtsVobuAddrMap %d\n", num);
   unsigned long *pLBA = pMovie->pAm->NewLBA(num);
   for (i = 0; i < num; i++, ptr += 4) {
      *pLBA++ = get4Bytes(ptr);
   }
}
