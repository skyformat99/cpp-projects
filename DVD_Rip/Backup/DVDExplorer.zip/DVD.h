// DVD.h: interface for the CDVD class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DVD_H__B58D4D05_F3E4_4E39_B9E9_91CBC0BE0D2A__INCLUDED_)
#define AFX_DVD_H__B58D4D05_F3E4_4E39_B9E9_91CBC0BE0D2A__INCLUDED_

#include "Movie.h"
#include "Angle.h"
#include "Ifo.h"
#include <afxtempl.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDVD  
{
private:
   int CellCount;
   t_VMG *pVMG;

public:
	CDVD();
	virtual ~CDVD();

   void Clean();
   BOOL SearchDVDDrive();
   BOOL SetPath(CString &path);
   inline CString GetPath() { return Path; }
   inline CString GetTitle() { return Title; }
   inline CAngle *GetSelAngle() { return pSelAngle; }
   BOOL ReadVMG_IFO();
   void Calculate();
   void FindIFO();

   CStringList *ErrorMsg() { return (errMsg.IsEmpty())? NULL: &errMsg; }

   CList<CMovie*, CMovie*> Movie;
   CMovie *AddMovie();

   BOOL MovieTreeUpdate(CTreeCtrl *pTreeCtrl);
   void TreeChange(CTreeCtrl *pTreeCtrl);
   void VideoInfoUpdate(CListCtrl *pLstVideoInfo);

   void ChaptersUpdate(CListCtrl *pLstChapters);
   void ChaptersCheckUpdate(CListCtrl *pLstChapters);
   void ChaptersSetCheck(int item, UINT state);
   void ChapterSelected(CListCtrl *pLstChapters);

   void CellsUpdate(CListCtrl *pLstCells);
   void CellsCheckUpdate(CListCtrl *pLstCells);
   void CellsCheck(CListCtrl *pLstCells);
   void CellsSelected(CListCtrl *pLstCells);

   void TotalSelUpdate(CListCtrl *pLstTotalSel);
   void SelChapterUpdate(CListCtrl *pLstSelChapter);
   void SelectedCell(CListCtrl *pLstSelChapter);
   void ShowStreamInfo(CListCtrl *pLstStreams);
   void FilesListUpdate(CListCtrl *pLstFiles, CMovie *pMovie);
   void FilesListUpdate(CListCtrl *pLstFiles, bool all = false);

   _int64 FreeSpace(LPCTSTR path);
   _int64 VobSize(CMovie *pMovie, DWORD record, bool all);
   _int64 RequiredSpace(CMovie *pMovie, DWORD record, bool all);
   _int64 RequiredSpace(bool all, DWORD record = 2048);

private:
   CString Path;           // vob and ifo directory's file
   CString Title;          // title of the movie
   CStringList errMsg;     // error messages

   CMovie   *pSelMovie;    // selected item in displayed list or tree
   CAngle   *pSelAngle;
   CChapter *pSelChapter;
   CCell    *pSelCell;

   bool     srcIsDvd;
   DWORD    diskRL;        // record length of the disk
};

#endif // !defined(AFX_DVD_H__B58D4D05_F3E4_4E39_B9E9_91CBC0BE0D2A__INCLUDED_)
