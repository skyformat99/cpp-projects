#if !defined(AFX_DIRPICKDLG_H__0CFB6B60_90A6_49C2_9442_01751EE59FD9__INCLUDED_)
#define AFX_DIRPICKDLG_H__0CFB6B60_90A6_49C2_9442_01751EE59FD9__INCLUDED_

#include "DirTreeCtrl.h"
#include "Resource.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DirPickDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDirPickDlg dialog

class CDirPickDlg : public CDialog
{
// Construction
public:
	CDirPickDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDirPickDlg)
	enum { IDD = IDD_IDIRPICK_DLG };
	CDirTreeCtrl	m_treeFiles;
	CString	m_selected;
	//}}AFX_DATA

   BOOL m_directory;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDirPickDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDirPickDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangedTreeFiles(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnUpdateEdSelect();
	afx_msg void OnKillfocusEdSelect();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CErrorDlg dialog

class CErrorDlg : public CDialog
{
// Construction
public:
	CErrorDlg(CStringList *pErrorList, CWnd* pParent = NULL);

// Dialog Data
	//{{AFX_DATA(CErrorDlg)
	enum { IDD = IDD_ERROR_DLG };
	CListCtrl	m_lstError;
	//}}AFX_DATA

   CStringList *m_pErrorList;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CErrorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CErrorDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIRPICKDLG_H__0CFB6B60_90A6_49C2_9442_01751EE59FD9__INCLUDED_)
