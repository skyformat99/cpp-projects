// Movie.h: interface for the CMovie class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MOVIE_H__D7FF8047_825B_46AA_930E_3D77C024791D__INCLUDED_)
#define AFX_MOVIE_H__D7FF8047_825B_46AA_930E_3D77C024791D__INCLUDED_

#include "Cell.h"
#include "Video.h"
#include "Audio.h"
#include "SubPicture.h"
#include "StreamProcessing.h"
#include "TimeMapTable.h"
#include "UnitManager.h"
#include "AddressMap.h"
#include <afxtempl.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef struct {
   _int64 size;
   unsigned char checked;
   unsigned char no;
   unsigned char title;
} t_VOB;

class CMovie  
{
private:
   CStringList *pErrMsg;
   _int64 VobSize;            // Size of all VOBs
   short number;              // CMovie number in list

public:
	CMovie(CStringList *pErrMsg);
	virtual ~CMovie();

   CString GetIfoName();
   short GetNumber() { return number; }
   CString GetName();

   unsigned long IfoSize;     // Size of IFO file

   CList<t_VOB, t_VOB&> VOB;  // a list of VOBs the movie
   int AddVobFile(short no, _int64 Size);
   CString GetVobFile(t_VOB *pVob);

   // round at the nearest MB (1MB = 1024*1024 = 0x100000)
   inline unsigned long GetVobSizeMb() { return unsigned long((VobSize + 0x10000) / 0x100000); }
   inline bool CheckSize(DWORD LBA) { return (LBA <= DWORD(VobSize / 2048)); }

   // Functions
   void ParseIFOFile(CString &path, short no);
   void AngleDetect();
   void InsertCells();
   void NewAngleDetect();
   void NewInsertCells();
   void CalcDatarates();
   int GetTimeForLBA(unsigned long InLBA,unsigned long *OutTime);

   int GetDatarates(CCell *pTSCA);
   unsigned long lba, lbamx;

   CTimeMapTable  *pTmt;
   CUnitManager   *pUm;
   CAddressMap    *pAm;

   inline int GetTitleCnt() { return Video.Title.GetCount(); } 

   void StreamProcess();
   // Subclasses
   CVideo            Video;
   CAudio            Audio;
   CSubPicture       SubPicture;
   CStreamProcessing StreamProcessing;
};

#endif // !defined(AFX_MOVIE_H__D7FF8047_825B_46AA_930E_3D77C024791D__INCLUDED_)
