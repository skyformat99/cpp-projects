// DirPickDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DirPickDlg.h"
#include <Shlwapi.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDirPickDlg dialog

CDirPickDlg::CDirPickDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDirPickDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDirPickDlg)
	m_selected = _T("");
	//}}AFX_DATA_INIT
   m_directory = TRUE;
}

void CDirPickDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDirPickDlg)
	DDX_Control(pDX, IDC_TREE_FILES, m_treeFiles);
	DDX_Text(pDX, IDC_ED_SELECT, m_selected);
	//}}AFX_DATA_MAP
}

BOOL CDirPickDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
   m_treeFiles.NewTree("*.*", m_selected);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BEGIN_MESSAGE_MAP(CDirPickDlg, CDialog)
	//{{AFX_MSG_MAP(CDirPickDlg)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE_FILES, OnSelchangedTreeFiles)
	ON_EN_UPDATE(IDC_ED_SELECT, OnUpdateEdSelect)
	ON_EN_KILLFOCUS(IDC_ED_SELECT, OnKillfocusEdSelect)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDirPickDlg message handlers

void CDirPickDlg::OnUpdateEdSelect() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_UPDATE flag ORed into the lParam mask.
	UpdateData();
   if (!m_selected.IsEmpty())
      m_treeFiles.PathSelect(m_selected, TRUE);
}

void CDirPickDlg::OnSelchangedTreeFiles(NMHDR* pNMHDR, LRESULT* pResult) 
{
   CString &path = m_treeFiles.GetItemPath(NULL);
   if (!path.IsEmpty()) {
      // select only if is it a directory
      if (m_directory = ::PathIsDirectory(path)) {
         m_selected = path;
         UpdateData(FALSE);
      } else {
         m_treeFiles.PathSelect(m_selected, TRUE);
      }
   }
	
	*pResult = 0;
}

void CDirPickDlg::OnKillfocusEdSelect() 
{
//	UpdateData();
//      m_treeFiles.PathSelect(m_selected, TRUE);
}
/////////////////////////////////////////////////////////////////////////////
// CErrorDlg dialog

CErrorDlg::CErrorDlg(CStringList *pErrorList, CWnd* pParent /*=NULL*/)
	: CDialog(CErrorDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CErrorDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
   m_pErrorList = pErrorList;
}

void CErrorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CErrorDlg)
	DDX_Control(pDX, IDC_LST_ERROR, m_lstError);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CErrorDlg, CDialog)
	//{{AFX_MSG_MAP(CErrorDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CErrorDlg message handlers

BOOL CErrorDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
   m_lstError.InsertColumn(0, "");
   if (m_pErrorList) {
      POSITION pos = m_pErrorList->GetHeadPosition();
      while (pos) m_lstError.InsertItem(0xFFFF, m_pErrorList->GetNext(pos));

      m_lstError.SetColumnWidth(0, LVSCW_AUTOSIZE);
   }
   
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
