// AudioStream.h: interface for the CAudioStream class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AUDIOSTREAM_H__04D827DA_C8E4_483A_8077_3C4D76BBFF0D__INCLUDED_)
#define AFX_AUDIOSTREAM_H__04D827DA_C8E4_483A_8077_3C4D76BBFF0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAudioStream  
{
public:
	CAudioStream();
	virtual ~CAudioStream();

   unsigned char ID;          // 0xBD,0xC0,0xC8
   unsigned char SubID;       // 0x8x,0xA0
   unsigned char Audio_Mode;  // Index Audioformat

   CString Language;          // English,Deutsch,...
   CString Mode;
   CString Frequenz;
   CString ApplMode;
   CString Quantization;
   CString Caption;
};

#endif // !defined(AFX_AUDIOSTREAM_H__04D827DA_C8E4_483A_8077_3C4D76BBFF0D__INCLUDED_)
