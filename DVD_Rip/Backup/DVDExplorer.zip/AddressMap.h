// AddressMap.h: interface for the CAddressMap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ADDRESSMAP_H__115E1EAD_F35F_46B5_A3EC_F6A7EF040B0B__INCLUDED_)
#define AFX_ADDRESSMAP_H__115E1EAD_F35F_46B5_A3EC_F6A7EF040B0B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAddressMap  
{
private:
   unsigned long *pLBA;
   int LBAcnt;
public:
	CAddressMap();
	virtual ~CAddressMap();

   unsigned long *CAddressMap::NewLBA(int cnt);
   inline int GetLBAcnt() { return LBAcnt; }
   inline unsigned long *GetLBA() { return pLBA; }

};

#endif // !defined(AFX_ADDRESSMAP_H__115E1EAD_F35F_46B5_A3EC_F6A7EF040B0B__INCLUDED_)
