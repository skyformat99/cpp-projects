// StreamProcessing.cpp: implementation of the CStreamProcessing class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "StreamProcessing.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CStreamProcessing::CStreamProcessing()
{
   Enabled = 0;   // No StreamProcessing
}

CStreamProcessing::~CStreamProcessing()
{
   DeleteAllStream();
}
/////////////////////////////////////////////////////////////////////////////
//

void CStreamProcessing::DeleteAllStream()
{
   while (!Stream.IsEmpty()) delete Stream.RemoveHead();
}
/////////////////////////////////////////////////////////////////////////////
//

CStream *CStreamProcessing::AddStream()
{
   CStream *tmp = new CStream();
   if (tmp) Stream.AddTail(tmp);

   return tmp;
}
