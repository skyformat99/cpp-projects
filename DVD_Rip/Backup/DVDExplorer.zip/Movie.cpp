// Movie.cpp: implementation of the CMovie class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Utilities.h"
#include "IFO.h"
#include "Movie.h"
#include <Shlwapi.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CMovie::CMovie(CStringList *pErrMsg)
{
   CMovie::pErrMsg = pErrMsg;
}

CMovie::~CMovie()
{
}
/////////////////////////////////////////////////////////////////////////////
//

CString CMovie::GetName()
{
   CString name;

   name.Format("Title %d [%lu MB]", GetNumber(), GetVobSizeMb());
   return name;
}
/////////////////////////////////////////////////////////////////////////////
// Read the IFO file and update a tree

void CMovie::ParseIFOFile(CString &path, short no)
{
   CIFO ifo(pErrMsg);
   TCHAR fname[MAX_PATH];
   _int64 size;
   CString name;

   number = no;
   VobSize = 0;
   while (!VOB.IsEmpty()) VOB.RemoveHead();

   // Find the corresponding VOBs Files
   for (unsigned short i = 0; i < VOBCOUNTER; i++) {

      name.Format("vts_%02d_%d.vob", no, i);
      ::PathCombine(fname, path, name);
      size = GetFileLength(fname);
      if (size >= 0) {
         VobSize += size;
         AddVobFile(i, size);
      } else if (i > 0) break; 
   }

   // file name of the IFO file
   name.Format("vts_%02d_0.ifo", no);
   ::PathCombine(fname, path, name);

   TRACE("CMovie::ParseIFOFile A %s\n", fname);

   pTmt = new CTimeMapTable();
   pUm  = new CUnitManager();
   pAm  = new CAddressMap();

   TRACE("CMovie::ParseIFOFile B u=%d\n", pUm->Unit.GetCount());

   ifo.Read(fname, this);

   TRACE("CMovie::ParseIFOFile C u=%d\n", pUm->Unit.GetCount());

   NewAngleDetect();
   CalcDatarates();
   NewInsertCells();

   delete pTmt;
   delete pUm;
   delete pAm;

   TRACE("CMovie::ParseIFOFile D\n");
}
/////////////////////////////////////////////////////////////////////////////
//

void CMovie::NewAngleDetect()
{
//   TRACE("CMovie::NewAngleDetect titlecnt=%d\n", pUm->Unit.GetCount());

   POSITION pti = pUm->Unit.GetHeadPosition();
   while (pti) {
      CUnit *pUnit = pUm->Unit.GetNext(pti);

      unsigned char anum = 0;

      POSITION pos = pUnit->Cell.GetHeadPosition(), psv = pos, tmp;
      while (pos) {
         CCell *pCell = pUnit->Cell.GetAt(pos);

		   switch (pCell->ChainInfo & 0xc0) {
         case 0x00: // 00
            pCell->Angle = 0x11; // 1 of 1
            psv = pos;
            break;
         case 0x40: // 01
            pCell->Angle = 0xf1; // 1 of ?
            psv = pos;
            anum = 1;
            break;
         case 0x80: // 10
            pCell->Angle = 0xf0 | ++anum; // anum of ?
            break;
         case 0xc0: // 11
            pCell->Angle = 0xf0 | ++anum; // anum of ?
            anum <<= 4;
            tmp = psv;
            for (;;) {
               CCell *pCl = pUnit->Cell.GetAt(tmp);
               if ((pCl->Angle & 0xf0) == 0xf0)
                  pCl->Angle = (pCl->Angle & 0x0f) | anum;
               if (tmp == pos) break;
               pUnit->Cell.GetNext(tmp);
            } 
            break;
         }
         pUnit->Cell.GetNext(pos);
      }
      pUnit->AngleCounter = anum >> 4;
      if (pUnit->AngleCounter == 0) pUnit->AngleCounter = 1;
   }
}
/////////////////////////////////////////////////////////////////////////////
//

void CMovie::AngleDetect()
{
   // Find Angles
   // Position = 0 => general Cell
   // Position > 0 => Angle

   unsigned int angle = 0;
	unsigned int highestlba = 0;
   unsigned int angledetection = 0;
   unsigned int maxangle = 0;
   unsigned long l_InEnd = 0,l_InVobID = 0;

   POSITION pos = pUm->TSCA.GetHeadPosition(), startCell = pos, tmp;
   while (pos) {
      CCell *pCell = pUm->TSCA.GetAt(pos);

      pCell->Position = 0;

		if (pCell->LBAStop < l_InEnd) {	// new Angle !!!
		
			angle++;
			for (tmp = startCell; tmp != pos; ) {
            pUm->TSCA.GetNext(tmp)->Position = angle;
         }
			startCell = pos;
			angledetection = 1;
		}

		if (pCell->LBAStart > highestlba && angledetection
        && pCell->VobID != l_InVobID) {// lastAngle found
		
			angledetection = 0;
			if (++angle > maxangle) maxangle = angle;

			for (tmp = startCell; tmp != pos;) {
                pUm->TSCA.GetNext(pos)->Position = angle;
         }
			angle = 0;
			startCell = pos;
		}

		l_InEnd = pCell->LBAStop;
    	l_InVobID = pCell->VobID;
		if (pCell->LBAStop > highestlba) highestlba = pCell->LBAStop;

		if (!angledetection) {
//            pCell->Position = angle;
		}
//        pCell->Position = angle;
/*
        TRACE("Angle: %2d  VobID: %2d  CellID: %2d   %7d %7d\n",
               pCell->Position,
               pCell->VobID,
               pCell->CellID,
               pCell->LBAStart,
               pCell->LBAStop);
        */
      pUm->TSCA.GetNext(pos);
   }
}
/////////////////////////////////////////////////////////////////////////////
//

void CMovie::NewInsertCells()
{
   unsigned int title, cell, angle;

   unsigned int TitleCount = pUm->Unit.GetCount();
   if (TitleCount == 0) return;

   unsigned int TSCACount = pUm->TSCA.GetCount();
   if (TSCACount == 0) return;

   TRACE("CMovie::NewInsertCells titleCnt=%d TSCACnt=%d\n", TitleCount, TSCACount);

   // Create Titles
   for (title = 0; title < TitleCount; title++) {
      CTitle *pTitle = Video.AddTitle();

      // Fill Titles

      CUnit *pUnit = pUm->GetUnitAt(title);

      unsigned int AngleCount = pUnit->AngleCounter;

      // Create Angles
      for (angle = 0; angle < AngleCount; angle++) {

         CAngle *pAngle = pTitle->AddAngle();
         pAngle->TotalPlayTime = pUnit->TotalPlayTime;

         // Create Chapters
         unsigned int chapter, LBAStop = 0;
         unsigned int ChapterCount = pUnit->GetCellLinkCount();
         for (chapter = 0; chapter < ChapterCount; chapter++) {

            CChapter *pChapter = pAngle->AddChapter();
            unsigned short cbegin,cend;

            // Insert Cells
            cbegin = pUnit->GetCellLink(chapter) - 1;
            if (chapter == ChapterCount - 1) // last chapter ?
               cend = pUnit->Cell.GetCount(); // untill last cell
            else
               cend = pUnit->GetCellLink(chapter + 1) - 1;

            if (cend > pUnit->Cell.GetCount()) {
               TRACE("CMovie::NewInsertCells cend ovf=%d max=%d\n",
                  cend, pUnit->Cell.GetCount());

               CString error;
               error.Format("Cell index overflow (%d for %d max)",
                  cend, pUnit->Cell.GetCount());
               pErrMsg->AddHead(error);
               cend = pUnit->Cell.GetCount();
            }

            for (cell = cbegin; cell < cend; cell++) {
               unsigned char CellAngle, insert = 0;
               CCell *pCell = pUnit->GetCellAt(cell);

               CellAngle = pCell->Angle & 0x0f;
               if (pCell->Angle != 0x11) {
                  if (CellAngle == angle + 1 || CellAngle == 0) insert = 1;
               } else insert = 1;

               if (insert) {
                  unsigned char timechecker = 0;

                  // Search VobIDCellID in TSCA
                  POSITION pos = pUm->TSCA.GetHeadPosition();
                  while (pos) {
                     CCell *pTSCA = pUm->TSCA.GetNext(pos);

                     if (pCell->VobID == pTSCA->VobID && pCell->CellID == pTSCA->CellID
                       && (pTSCA->LBAStart > LBAStop || pTSCA->number == 0) ) { // filter duplicates
                    
                        // Insert Cell
                        pChapter->AddCell(pTSCA->number, // Position
                                          pTSCA->VobID, pTSCA->CellID,
                                          pTSCA->LBAStart, pTSCA->LBAStop,
                                          timechecker? 0:
                              pUm->GetUnitAt(title)->GetCellAt(cell)->Length,
                                          pTSCA->AverageDatarate,
                                    pTSCA->MinDatarate, pTSCA->MaxDatarate);

                        LBAStop = pTSCA->LBAStop;
                        timechecker = 1;
                     }
                  } // end while loop
               }
            } // end for loop
         }
      }
   }
}
/////////////////////////////////////////////////////////////////////////////
//

void CMovie::InsertCells()
{
   unsigned int TitleCount=0;
   unsigned int AngleCount=0;
   unsigned int TSCACount=0;
   unsigned int ChapterCount=0;
   unsigned int angle;
   unsigned int cangle;
   unsigned int gangle;
   unsigned int cellpos;
   unsigned int chapter;
   unsigned char check[1000];
   unsigned int tmp;

   TitleCount = pUm->Unit.GetCount();
   if (TitleCount == 0) return;

   TSCACount = pUm->TSCA.GetCount();
   if (TSCACount == 0) return;

   TRACE("CMovie::InsertCells tileCnt=%d TSCACnt=%d\n", TitleCount, TSCACount);

    // Create Titles and Fill there
   POSITION utlp = pUm->Unit.GetHeadPosition();
   while (utlp) {
      CUnit *pUUnit = pUm->Unit.GetNext(utlp);

      // create a new title
      CTitle *pVTitle = Video.AddTitle();

      // Count Angles in Title
      AngleCount = 0;

      // reset AngleCheckList
      for (cangle = 0; cangle < 1000; cangle++) check[cangle] = 0;

      // Parse CellPositions
      POSITION celp = pUUnit->Cell.GetHeadPosition();
      while (celp) {
         CCell *pUCell = pUUnit->Cell.GetNext(celp);

         // Search VobIDCellID in TSCA
         POSITION tsca = pUm->TSCA.GetHeadPosition();
         while (tsca) {
            CCell *pTSCA = pUm->TSCA.GetNext(tsca);

            if (pUCell->VobID == pTSCA->VobID && pUCell->CellID == pTSCA->CellID) {
               cangle = pTSCA->Position;
               check[cangle] = 1;

/*             TRACE("Angle: %2d  VobID: %2d  CellID: %2d   %7d %7d\n",
                              um->pTSCA(TSCApos)->Position,
                              um->pTSCA(TSCApos)->VobID,
                              um->pTSCA(TSCApos)->CellID,
                              um->pTSCA(TSCApos)->LBAStart,
                              um->pTSCA(TSCApos)->LBAStop);
*/
            }
         }
      }
      // Angle 1->999 check if present
      for (cangle = 0; cangle < 1000; cangle++) {
         if (check[cangle] == 1) AngleCount++;
      }
      if (AngleCount > 0) {
         if (--AngleCount == 0) AngleCount = 1;
      } else AngleCount = 1;

      // Search Global AngleNumber;
      if (check[0] == 0) {
         tmp = 0;
         cangle = 0;
         while(tmp == 0 && cangle < 1000) {
            cangle++;
            if (check[cangle] == 1) tmp = 1;
         }
         gangle = cangle;
      } else gangle = 0;

      // Create Angles
      for (angle = 0; angle < AngleCount; angle++) {

         CAngle *pAngle = pVTitle->AddAngle();
         pAngle->TotalPlayTime = pUUnit->TotalPlayTime;

         // Search AngleNumber;
         tmp = 0;
         cangle = 0;
         while(tmp != angle + 1 && cangle < 1000) {
             cangle++;
             if (check[cangle] == 1) tmp++;
         }

         // Create Chapters
         unsigned int LBAStop = 0;
         ChapterCount = pUUnit->GetCellLinkCount();
         for (chapter = 0;chapter < ChapterCount; chapter++) {
            CChapter *pChapter = pAngle->AddChapter();

            // Parse Cells in Chapter
            unsigned short cbegin,cend;
            cbegin = pUUnit->GetCellLink(chapter) - 1;
            if (chapter == ChapterCount - 1) // last chapter ?
               cend = pUUnit->Cell.GetCount(); // untill last cell
            else
               cend = pUUnit->GetCellLink(chapter + 1) - 1;

            // Search Cell in Chapter
            for (cellpos = cbegin; cellpos < cend; cellpos++) {
               unsigned char timechecker = 0;
               CCell *pCell = pUUnit->GetCellAt(cellpos);

               // Search VobIDCellID in TSCA with Angle=angle or 0
               POSITION pos = pUm->TSCA.GetHeadPosition();
               while (pos) {
                  CCell *pTSCA = pUm->TSCA.GetNext(pos);

                  if (pCell->VobID == pTSCA->VobID && pCell->CellID == pTSCA->CellID
                    && (pTSCA->Position == cangle || pTSCA->Position == gangle)
                    && (pTSCA->LBAStart > LBAStop || pTSCA->number == 0) ) {

                     // filter duplicate
                     pChapter->AddCell(pTSCA->number,   // Position
                                       pTSCA->VobID, pTSCA->CellID,
                                       pTSCA->LBAStart, pTSCA->LBAStop,
                                       timechecker ? 0 : pCell->Length,
                                       pTSCA->AverageDatarate,
                                       pTSCA->MinDatarate, pTSCA->MaxDatarate);

                     LBAStop = pTSCA->LBAStop;
                     timechecker = 1;
                  }
               }
            }
         }
      }
   }
}
/////////////////////////////////////////////////////////////////////////////
// Computs the data rate

void CMovie::CalcDatarates()
{
   TRACE("CMovie::CalcDatarates\n");
   POSITION pos = pUm->TSCA.GetHeadPosition();
   while (pos) {
      CCell *pTSCA = pUm->TSCA.GetNext(pos);
      GetDatarates(pTSCA);
/*
      unsigned long iLength = unsigned long(pTSCA->Length);
    	TRACE("  Pos=%u VobID=%u CellID=%u Start=%lu Stop=%lu Size=%lu AD=%lu\n"
            "     Len=%lums (%s) Min=%lu Max=%lu\n",
            pTSCA->Position,
            pTSCA->VobID,
            pTSCA->CellID,
            pTSCA->LBAStart,
            pTSCA->LBAStop,
            pTSCA->Size,
            pTSCA->AverageDatarate,
            iLength, msDecode(iLength, true),
            pTSCA->MinDatarate,
            pTSCA->MaxDatarate);
*/
   }
//   TRACE("CMovie::CalcDatarates end\n");

}
/////////////////////////////////////////////////////////////////////////////
//

int CMovie::GetDatarates(CCell *pTSCA)
{
   bool found_start = false, found_end = false;
   unsigned long c_time = 0;        // Current Time of LBA in ms
   unsigned long l_time = 0;        // Last Time of LBA in ms
   unsigned long c_pos = 0;         // Current LBA Position
   unsigned long s_pos = 0;	      // Start LBA Position (found)
   unsigned long e_pos = 0;         // End LBA Position (found)
   unsigned long l_pos = 0;         // Last LBA Position
   unsigned long c_datarate = 0;    // Current Datarate
   unsigned long CellBlocks = 0;
   int LBAcnt = pAm->GetLBAcnt();
   unsigned long *pLBA = pAm->GetLBA();
   unsigned long LBAStart = pTSCA->LBAStart;
   unsigned long LBAStop = pTSCA->LBAStop;
   unsigned long AvgDatarate = pTSCA->AverageDatarate;
   unsigned long MaxDatarate = 0;
   unsigned long MinDatarate = ULONG_MAX;
   unsigned long Length;

   for (int i = 0; i < LBAcnt && !found_end; i++) {
      c_pos = pLBA[i];

		if (!found_start && c_pos >= LBAStart) {
			found_start = true;
			s_pos = c_pos;
		}
		if (!found_end && found_start && c_pos > LBAStop) {
			found_end = true;
		}
		if (found_start && !found_end) {
			CellBlocks++;
			GetTimeForLBA(c_pos, &c_time);
			if (c_time - l_time != 0 && CellBlocks > 1) {

				c_datarate = ((c_pos - l_pos) * 2048000) / (c_time - l_time);

            if (c_datarate > MaxDatarate) MaxDatarate = c_datarate;
            if (c_datarate < MinDatarate) MinDatarate = c_datarate, lba = i;
         }
		}
		l_pos = c_pos;
		l_time = c_time;
	}
   lbamx = i;

   GetTimeForLBA(LBAStart, &l_time);
   GetTimeForLBA(LBAStop,  &c_time);
   Length = c_time - l_time;

   if (Length > 0) {
      unsigned int t1;

      t1 = (LBAStop - LBAStart + 1) * 2048;
      AvgDatarate = (t1 / Length) * 1000;
      if (AvgDatarate > MaxDatarate) MaxDatarate = AvgDatarate;
      if (AvgDatarate < MinDatarate) MinDatarate = AvgDatarate, lba = ULONG_MAX;
   }
   pTSCA->AverageDatarate  = AvgDatarate;
   pTSCA->MaxDatarate      = MaxDatarate;
   pTSCA->MinDatarate      = MinDatarate;

	return found_end;
}
/////////////////////////////////////////////////////////////////////////////
//

int CMovie::GetTimeForLBA(unsigned long InLBA, unsigned long *pOutTime)
{
   long Step = pTmt->Step * 1000;

   if (Step <= 0) return FALSE;

   if (InLBA > 0) {
      // reverse search in LBA table
      int i = 0, dlt = 0x10000, LBAcnt = pTmt->GetLBAcnt() - 1;
      unsigned long *pLBA = pTmt->pLBA, outTime;

      while (dlt >>= 1) {
         i += dlt;
         if (i > LBAcnt || pLBA[i] > InLBA) i -= dlt;
      }

      outTime = Step * i;

      if (i < LBAcnt && InLBA > pLBA[i] && pLBA[i+1] > pLBA[i])
         outTime += (Step * (InLBA - pLBA[i])) / (pLBA[i+1] - pLBA[i]);

      *pOutTime = outTime;
   } else *pOutTime = 0;

   return TRUE;
}
/////////////////////////////////////////////////////////////////////////////
//

void CMovie::StreamProcess()
{
   int RipMode = 0;

   StreamProcessing.DeleteAllStream();

   // First stream : the video
   CStream *pStream = StreamProcessing.AddStream();
   pStream->Type = 0;
   pStream->ID = 0xE0;
   pStream->SubID = 0;
   pStream->AllowMapping = 1;
   pStream->Map = 0;
   pStream->mID = 0xE0;
   pStream->mSubID = 0;
   pStream->Checked = 1;
   pStream->AllowExtraction = 1;
   pStream->ShortName = "[0xE0] Video";
   pStream->Name.Format("[0xE0] Video %s / %s / %s", Video.TVsystem,
                           Video.AspectRatio, Video.SourceRes);
   pStream->RipMode = 0;
   pStream->Ext = "m2v";

   // Audio streams
   int n = 0;
   POSITION pos = Audio.AudioStream.GetHeadPosition();
   while (pos) {
      CAudioStream *pAudioStream = Audio.AudioStream.GetNext(pos);

      if (Audio.Avail[n] >= 0) {
         unsigned char id;

         pStream = StreamProcessing.AddStream();

         if (pAudioStream->ID == 0xBD) {
            id = pAudioStream->SubID;
            switch (id & 0xF8) {
            case 0x80 : pStream->Ext = "ac3"; break;
            case 0x88 : pStream->Ext = "dts"; break;
            case 0xF0 : pStream->Ext = "wav"; break;
            }
            /*
            if (pAudioStream->SubID >= 0x80 && pAudioStream->SubID <= 0x87) pStream->Ext = "ac3";
            if (pAudioStream->SubID >= 0x88 && pAudioStream->SubID <= 0x8F) pStream->Ext = "dts";
            if ((pAudioStream->SubID & 0xF0) == 0xA0) pStream->Ext = "wav";*/
         } else {
            id = pAudioStream->ID;
            pStream->Ext = "mp2";
         }

         pStream->Type = 1;
         pStream->ID = pAudioStream->ID;
         pStream->SubID = pAudioStream->SubID;
         pStream->AllowMapping = 1;
         pStream->Map = 0;
         pStream->mID = pAudioStream->ID;
         pStream->mSubID = pAudioStream->SubID;
         pStream->Checked = 1;
         pStream->AllowExtraction = 1;
         pStream->RipMode = RipMode;
         pStream->ShortName.Format("[0x%X] Audio", id);
         pStream->Name.Format("[0x%X] Audio %s %s %s %s %s %s", id, pAudioStream->Language,
                        pAudioStream->Mode, pAudioStream->Frequenz, pAudioStream->Quantization,
                                    pAudioStream->ApplMode, pAudioStream->Caption);
         n++;
      }
   }

   // Subtitles
   n = 0;
   pos = SubPicture.SubPictureStream.GetHeadPosition();
   while (pos) {
      CSubPictureStream *pSubPictureStream = SubPicture.SubPictureStream.GetNext(pos);
      if (SubPicture.Avail[n++] >= 0) {

         pStream = StreamProcessing.AddStream();

         pStream->Type = 2;
         pStream->ID = pSubPictureStream->ID;
         pStream->SubID = pSubPictureStream->SubID;
         pStream->AllowMapping = 1;
         pStream->Map = 0;
         pStream->mID = pSubPictureStream->ID;
         pStream->mSubID = pSubPictureStream->SubID;
         pStream->Checked = 0;
         pStream->AllowExtraction = 1;
         pStream->RipMode = RipMode;
         pStream->ShortName.Format("[0x%X] Subtitle", pSubPictureStream->SubID);
         pStream->Name.Format("[0x%X] SubTitle %s %s", pSubPictureStream->SubID,
                              pSubPictureStream->Language, pSubPictureStream->Caption);
         pStream->Ext = "rawsub";
      }
   }

   // Others
   pStream = StreamProcessing.AddStream();

   pStream->Type = 3;
   pStream->ID = 0;
   pStream->SubID = 0;
   pStream->AllowMapping = 0;
   pStream->Map = 0;
   pStream->mID = 0;
   pStream->mSubID = 0;
   pStream->Checked = 1;
   pStream->AllowExtraction = 0;
   pStream->RipMode = 0;
   pStream->ShortName = "[0x??] Others";
   pStream->Name = "[0x??] Others";
}
/////////////////////////////////////////////////////////////////////////////
//

int CMovie::AddVobFile(short no, _int64 size)
{
   t_VOB vob;

   vob.size = size;
   vob.no = unsigned char(no);
   vob.title = unsigned char(number);
   vob.checked = 1;
   VOB.AddTail(vob);
   return VOB.GetCount() - 1;
}

CString CMovie::GetIfoName()
{
   CString name;
   name.Format("vts_%02d_0.ifo", number);
   return name;
}

CString CMovie::GetVobFile(t_VOB *pVob)
{
   CString name;
   name.Format("vts_%02d_%d.vob", pVob->title, pVob->no);
   return name;
}
