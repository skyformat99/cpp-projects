// DVDExplorerDlg.h : header file
//

#if !defined(AFX_DVDEXPLORERDLG_H__665DD5F2_7D59_470E_AE5C_1B0D1C94EB67__INCLUDED_)
#define AFX_DVDEXPLORERDLG_H__665DD5F2_7D59_470E_AE5C_1B0D1C94EB67__INCLUDED_

#include "DVD.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDVDExpDlg dialog

class CDVDExpDlg : public CDialog
{
// Construction
public:
	CDVDExpDlg(CWnd* pParent = NULL);	// standard constructor

   CDVD DVD;
	void DVDRead(CString path);
   void DVDSearchAndRead();

   // Dialog Data
	//{{AFX_DATA(CDVDExpDlg)
	enum { IDD = IDD_DVDEXPLORER_DLG };
	CTreeCtrl	m_treeTitle;
	CListCtrl	m_lstVideoInfo;
	CListCtrl	m_lstTotalSel;
	CListCtrl	m_lstStreams;
	CListCtrl	m_lstSelChapter;
	CListCtrl	m_lstChapters;
	CListCtrl	m_lstCells;
	CString	m_edtFile;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDVDExpDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
   int   m_timer;
   CImageList m_iml;
   CImageList m_ichk;

	// Generated message map functions
	//{{AFX_MSG(CDVDExpDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnFile();
	afx_msg void OnSelchangedTreeTitle(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickLstChapters(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnBtnError();
	afx_msg void OnClickLstCells(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBtnDvd();
	//}}AFX_MSG
   afx_msg void OnDropFiles(HDROP hDropInfo);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DVDEXPLORERDLG_H__665DD5F2_7D59_470E_AE5C_1B0D1C94EB67__INCLUDED_)
