// Stream.cpp: implementation of the CStream class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Stream.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

CStream::CStream()
{
    Type = 0;
    ID = 0;
    SubID = 0;
    AllowMapping = 0;
    Map = 0;
    mID = 0;
    mSubID = 0;
    Checked = 0;
    AllowExtraction = 0;
    RipMode = 0;
    Datarate = 0;
    LBA = 0;
    PTS = 0;
}

CStream::~CStream()
{
}
