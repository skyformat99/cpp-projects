// Video.h: interface for the CVideo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VIDEO_H__298C3755_D4A6_474F_981E_AF636D98EA88__INCLUDED_)
#define AFX_VIDEO_H__298C3755_D4A6_474F_981E_AF636D98EA88__INCLUDED_

#include "Title.h"
#include <afxtempl.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CVideo  
{
public:
	CVideo();
	virtual ~CVideo();

   //Properties
   CString Compression;
   CString TVsystem;
   CString AspectRatio;
   CString DisplayMode;
   CString Line211;
   CString Line212;
   CString SourceRes;
   CString Letterboxed;
   CString Mode;

   unsigned int MovieTitle;    // first Title with Time>15min

   CList<CTitle*, CTitle*> Title;
   CTitle *AddTitle();

   void Calculate();
};

#endif // !defined(AFX_VIDEO_H__298C3755_D4A6_474F_981E_AF636D98EA88__INCLUDED_)
